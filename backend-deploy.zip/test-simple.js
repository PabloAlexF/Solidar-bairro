const axios = require('axios');

const API_BASE = 'http://localhost:3001/api';

async function testSimple() {
  console.log('🧪 Teste Simples das APIs\n');

  // 1. Testar Cidadão
  console.log('👤 Testando API Cidadão...');
  try {
    const response = await axios.post(`${API_BASE}/cidadaos`, {
      nome: 'João Silva',
      email: 'joao@teste.com',
      telefone: '(31) 99999-1111',
      cpf: '123.456.789-01',
      dataNascimento: '1990-05-15',
      endereco: {
        cep: '30112-000',
        logradouro: 'Rua da Bahia',
        numero: '123',
        bairro: 'Centro',
        cidade: 'Belo Horizonte',
        estado: 'MG'
      },
      senha: '123456'
    });
    console.log('✅ Cidadão:', response.data);
  } catch (error) {
    console.log('❌ Erro Cidadão:', error.response?.data || error.message);
  }

  // 2. Testar Login
  console.log('\n🔐 Testando Login...');
  try {
    const response = await axios.post(`${API_BASE}/auth/login`, {
      email: 'joao@teste.com',
      password: '123456'
    });
    console.log('✅ Login:', response.data.message);
    console.log('   Token:', response.data.token.substring(0, 20) + '...');
  } catch (error) {
    console.log('❌ Erro Login:', error.response?.data || error.message);
  }
}

testSimple();