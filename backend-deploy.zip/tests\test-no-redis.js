const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

async function testWithoutRedis() {
  console.log('🧪 TESTANDO APIs SEM REDIS\n');
  console.log('=' .repeat(50));
  
  // Test health endpoint
  try {
    const health = await axios.get('http://localhost:3001/health');
    console.log('✅ Health endpoint:', health.data.status);
  } catch (error) {
    console.log('❌ Health endpoint error:', error.message);
  }
  
  // Test address APIs
  const tests = [
    { name: 'CEP válido', url: `${BASE_URL}/address/cep/01310100` },
    { name: 'Busca endereço', url: `${BASE_URL}/address/search?uf=SP&cidade=São Paulo&logradouro=Rua` }
  ];
  
  for (const test of tests) {
    try {
      const response = await axios.get(test.url);
      console.log(`✅ ${test.name}: ${response.status}`);
    } catch (error) {
      console.log(`❌ ${test.name}: ${error.response?.status || error.message}`);
    }
  }
  
  console.log('\n📋 CONFIGURAÇÃO ATUAL:');
  console.log('• Redis: DESABILITADO');
  console.log('• Cache: Funcionando sem Redis');
  console.log('• Rate Limiting: Ativo');
  console.log('• Logs: Ativos');
  console.log('• Fallback APIs: Configuradas');
}

testWithoutRedis().catch(console.error);