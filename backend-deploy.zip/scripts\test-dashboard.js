const axios = require('axios');
require('dotenv').config();

const API_BASE = 'http://localhost:3001/api';

async function testDashboard() {
  console.log('📊 Testando Dashboard Completo...\n');

  const testUsers = [
    { email: 'joao@teste.com', senha: '123456', tipo: 'Cidadão' },
    { email: 'maria@teste.com', senha: '123456', tipo: 'Família' },
    { email: 'contato@solidariedadebh.org', senha: '123456', tipo: 'ONG' }
  ];

  for (const user of testUsers) {
    try {
      console.log(`\n🔐 Testando login para ${user.tipo}...`);
      
      // 1. Login
      const loginResponse = await axios.post(`${API_BASE}/auth/login`, {
        email: user.email,
        senha: user.senha
      });

      const token = loginResponse.data.token;
      const userData = loginResponse.data.user;
      
      console.log(`✅ Login realizado com sucesso`);
      console.log(`   Nome: ${userData.nome || userData.nomeResponsavel || userData.nomeFantasia}`);
      console.log(`   Tipo: ${userData.tipo}`);

      // Headers para requisições autenticadas
      const authHeaders = {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      };

      // 2. Testar dados do usuário
      console.log(`\n📋 Testando dados do dashboard para ${user.tipo}...`);
      
      if (userData.tipo === 'cidadao') {
        try {
          const cidadaoData = await axios.get(`${API_BASE}/cidadaos/${userData.uid}`, { headers: authHeaders });
          console.log(`✅ Dados do cidadão carregados`);
        } catch (error) {
          console.log(`❌ Erro ao carregar dados do cidadão:`, error.response?.data?.message);
        }
      }

      if (userData.tipo === 'familia') {
        try {
          const familiaData = await axios.get(`${API_BASE}/familias/${userData.uid}`, { headers: authHeaders });
          console.log(`✅ Dados da família carregados`);
        } catch (error) {
          console.log(`❌ Erro ao carregar dados da família:`, error.response?.data?.message);
        }
      }

      if (userData.tipo === 'ong') {
        try {
          const ongData = await axios.get(`${API_BASE}/ongs/${userData.uid}`, { headers: authHeaders });
          console.log(`✅ Dados da ONG carregados`);
        } catch (error) {
          console.log(`❌ Erro ao carregar dados da ONG:`, error.response?.data?.message);
        }
      }

      // 3. Testar estatísticas (se disponível)
      try {
        const statsResponse = await axios.get(`${API_BASE}/stats/dashboard`, { headers: authHeaders });
        console.log(`✅ Estatísticas do dashboard carregadas`);
      } catch (error) {
        console.log(`⚠️ Estatísticas não disponíveis:`, error.response?.data?.message || 'Endpoint não encontrado');
      }

      // 4. Testar notificações (se disponível)
      try {
        const notificationsResponse = await axios.get(`${API_BASE}/notifications`, { headers: authHeaders });
        console.log(`✅ Notificações carregadas`);
      } catch (error) {
        console.log(`⚠️ Notificações não disponíveis:`, error.response?.data?.message || 'Endpoint não encontrado');
      }

      console.log(`✅ Dashboard ${user.tipo} testado com sucesso!`);

    } catch (error) {
      console.log(`❌ Erro no teste do ${user.tipo}:`, error.response?.data?.message || error.message);
    }
  }

  console.log('\n🎉 Teste completo do dashboard finalizado!');
  console.log('\n📱 Funcionalidades testadas:');
  console.log('   ✅ Sistema de login');
  console.log('   ✅ Carregamento de dados do usuário');
  console.log('   ✅ Autenticação com token');
  console.log('   ⚠️ Estatísticas (se disponível)');
  console.log('   ⚠️ Notificações (se disponível)');
  
  console.log('\n🌐 Próximos passos:');
  console.log('   1. Acesse http://localhost:3000');
  console.log('   2. Faça login com qualquer uma das credenciais');
  console.log('   3. Explore o dashboard específico de cada tipo');
}

testDashboard().catch(console.error);