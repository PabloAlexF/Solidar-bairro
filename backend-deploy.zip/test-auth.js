const firebase = require('./src/config/firebase');
const bcrypt = require('bcryptjs');

async function testFamiliaAuth() {
  try {
    console.log('🧪 Teste de autenticação de família\n');
    
    const db = firebase.getDb();
    
    // 1. Verificar se existe família
    console.log('1. Verificando famílias cadastradas...');
    const snapshot = await db.collection('familias').get();
    console.log(`   Total: ${snapshot.size} famílias`);
    
    if (snapshot.size > 0) {
      const familia = snapshot.docs[0];
      const data = familia.data();
      
      console.log('\n2. Dados da primeira família:');
      console.log(`   Email: ${data.email}`);
      console.log(`   Nome: ${data.nomeCompleto}`);
      console.log(`   Tem senha: ${!!data.senha}`);
      
      if (data.senha && data.email) {
        console.log('\n3. Testando verificação de senha...');
        
        // Testar senha 123456
        const isValid = await bcrypt.compare('123456', data.senha);
        console.log(`   Senha '123456' válida: ${isValid}`);
        
        if (isValid) {
          console.log('\n✅ Família pode fazer login com senha 123456');
        } else {
          console.log('\n❌ Senha não confere');
        }
      } else {
        console.log('\n❌ Família sem senha ou email');
      }
    } else {
      console.log('\n❌ Nenhuma família cadastrada');
    }
    
  } catch (error) {
    console.log('❌ Erro:', error.message);
  }
}

testFamiliaAuth();