const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

async function testRegistrations() {
  console.log('🧪 Testando cadastros...\n');

  // Test data
  const testData = {
    cidadao: {
      nome: 'João Silva',
      dataNascimento: '1990-01-01',
      ocupacao: 'Professor',
      cpf: '12345678901',
      rg: '123456789',
      telefone: '11999999999',
      email: 'joao.test@example.com',
      password: '123456',
      confirmPassword: '123456',
      endereco: {
        rua: 'Rua Teste',
        numero: '123',
        bairro: 'Centro',
        cidade: 'São Paulo',
        estado: 'SP',
        cep: '01234567'
      },
      disponibilidade: ['Segunda', 'Terça'],
      interesses: ['Educação', 'Saúde'],
      proposito: 'Quero ajudar a comunidade'
    },
    familia: {
      nomeCompleto: 'Maria Santos',
      dataNascimento: '1985-05-15',
      estadoCivil: 'Casada',
      profissao: 'Do lar',
      cpf: '98765432100',
      rg: '987654321',
      nis: '123456789',
      rendaFamiliar: '1001_2000',
      telefone: '11988888888',
      whatsapp: '11988888888',
      email: 'maria.test@example.com',
      horarioContato: 'Manhã',
      senha: '123456',
      confirmarSenha: '123456',
      endereco: 'Rua Família, 456, Bairro Família, São Paulo, SP',
      bairro: 'Bairro Família',
      pontoReferencia: 'Próximo ao mercado',
      tipoMoradia: 'Casa Própria',
      criancas: 2,
      jovens: 1,
      adultos: 2,
      idosos: 0,
      necessidades: ['Alimentos', 'Roupas']
    },
    ong: {
      nome: 'ONG Teste Solidária',
      cnpj: '12345678000123',
      email: 'ong.test@example.com',
      telefone: '11977777777',
      endereco: 'Rua ONG, 101, Centro, São Paulo, SP',
      areasAtuacao: ['Educação', 'Saúde'],
      descricao: 'ONG dedicada ao apoio comunitário',
      responsavel: {
        nome: 'João Responsável',
        telefone: '11977777777'
      },
      senha: '123456'
    },
    comercio: {
      nomeComercio: 'Padaria do Bairro Teste',
      cnpj: '12345678000124',
      email: 'comercio.test@example.com',
      telefone: '11966666666',
      endereco: 'Rua Comércio, 789, Centro, São Paulo, SP',
      categoria: 'Alimentação',
      descricao: 'Padaria com foco em produtos locais',
      horarioFuncionamento: {
        abertura: '06:00',
        fechamento: '20:00',
        dias: 'Segunda a Sábado'
      },
      senha: '123456'
    }
  };

  const results = {};

  // Test each registration type
  for (const [type, data] of Object.entries(testData)) {
    try {
      console.log(`📝 Testando cadastro de ${type}...`);

      const response = await axios.post(`${BASE_URL}/${type}s`, data);
      console.log(`   ✅ ${type} cadastrado com sucesso - ID: ${response.data.id || response.data.uid}`);

      // Verify the registration was saved
      const verifyResponse = await axios.get(`${BASE_URL}/${type}s`);
      const registros = verifyResponse.data.data || verifyResponse.data;
      const found = registros.find(r => r.email === data.email);

      if (found) {
        console.log(`   ✅ ${type} encontrado no banco de dados`);
        results[type] = { success: true, id: found.id || found.uid };
      } else {
        console.log(`   ❌ ${type} NÃO encontrado no banco de dados`);
        results[type] = { success: false, error: 'Not found in database' };
      }

    } catch (error) {
      console.log(`   ❌ Erro no cadastro de ${type}: ${error.response?.data?.message || error.message}`);
      results[type] = { success: false, error: error.message };
    }
    console.log('');
  }

  // Summary
  console.log('📊 Resumo dos testes:');
  Object.entries(results).forEach(([type, result]) => {
    const status = result.success ? '✅ Sucesso' : '❌ Falhou';
    console.log(`   ${type}: ${status}`);
    if (!result.success) {
      console.log(`      Erro: ${result.error}`);
    }
  });

  const successCount = Object.values(results).filter(r => r.success).length;
  console.log(`\n🎯 ${successCount}/${Object.keys(results).length} cadastros funcionando corretamente`);
}

testRegistrations().catch(console.error);
