const axios = require('axios');

const API_BASE = 'http://localhost:3001/api/bot';

async function testBotAPI() {
  console.log('🌐 Testando API do Bot Inteligente\n');

  try {
    // Teste 1: Endpoint de teste
    console.log('1. Testando endpoint /test...');
    const testResponse = await axios.get(`${API_BASE}/test`);
    console.log(`✅ Status: ${testResponse.status}`);
    console.log(`📊 Resultados: ${testResponse.data.results.length} testes`);
    console.log(`🎯 Taxa de sucesso: ${Math.round((testResponse.data.summary.passed / testResponse.data.summary.total) * 100)}%\n`);

    // Teste 2: Validação de pedido válido
    console.log('2. Testando validação de pedido válido...');
    const validRequest = {
      category: 'Alimentos',
      description: 'Preciso urgentemente de ajuda com comida para minha família. Somos 4 pessoas.',
      urgency: 'critico'
    };
    
    const validResponse = await axios.post(`${API_BASE}/validate`, validRequest);
    console.log(`✅ Status: ${validResponse.status}`);
    console.log(`📊 Resultado: ${validResponse.data.canPublish ? 'APROVADO' : 'REJEITADO'}`);
    console.log(`🎯 Confiança: ${validResponse.data.data.confidence}%\n`);

    // Teste 3: Validação de spam
    console.log('3. Testando detecção de spam...');
    const spamRequest = {
      category: 'Alimentos',
      description: 'dawdawdaw dawdawdaw preciso ajuda dawdawdaw',
      urgency: 'urgente'
    };
    
    const spamResponse = await axios.post(`${API_BASE}/validate`, spamRequest);
    console.log(`✅ Status: ${spamResponse.status}`);
    console.log(`📊 Resultado: ${spamResponse.data.canPublish ? 'APROVADO' : 'REJEITADO'}`);
    console.log(`💡 Sugestões: ${spamResponse.data.validation.suggestions.join('; ')}\n`);

    // Teste 4: Análise detalhada
    console.log('4. Testando análise detalhada...');
    const analysisResponse = await axios.post(`${API_BASE}/analyze`, validRequest);
    console.log(`✅ Status: ${analysisResponse.status}`);
    console.log(`📊 Pode publicar: ${analysisResponse.data.analysis.canPublish}`);
    console.log(`🎯 Score de risco: ${analysisResponse.data.analysis.riskScore}`);
    console.log(`📝 Resumo: ${analysisResponse.data.analysis.summary}\n`);

    console.log('🎉 Todos os endpoints da API estão funcionando perfeitamente!');

  } catch (error) {
    if (error.code === 'ECONNREFUSED') {
      console.log('❌ Erro: Servidor não está rodando. Execute "npm start" no backend primeiro.');
    } else if (error.response) {
      console.log(`❌ Erro HTTP ${error.response.status}: ${error.response.data.message}`);
    } else {
      console.log(`❌ Erro: ${error.message}`);
    }
  }
}

testBotAPI();