require('dotenv').config();
const nodemailer = require('nodemailer');

async function diagnosticTest() {
  console.log('🔍 Diagnóstico completo do Gmail SMTP...\n');
  
  console.log('📋 Configurações atuais:');
  console.log('SMTP_USER:', process.env.SMTP_USER);
  console.log('SMTP_PASS:', process.env.SMTP_PASS ? `${process.env.SMTP_PASS.substring(0, 4)}****` : 'NOT SET');
  console.log('');
  
  // Teste 1: Configuração service gmail
  console.log('🧪 Teste 1: service gmail');
  try {
    const transporter1 = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });
    
    await transporter1.verify();
    console.log('✅ Teste 1 passou - service gmail OK');
  } catch (error) {
    console.log('❌ Teste 1 falhou:', error.message);
  }
  
  // Teste 2: Configuração manual
  console.log('\n🧪 Teste 2: configuração manual');
  try {
    const transporter2 = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });
    
    await transporter2.verify();
    console.log('✅ Teste 2 passou - configuração manual OK');
  } catch (error) {
    console.log('❌ Teste 2 falhou:', error.message);
  }
  
  // Teste 3: Porta 465 (SSL)
  console.log('\n🧪 Teste 3: porta 465 SSL');
  try {
    const transporter3 = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 465,
      secure: true,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });
    
    await transporter3.verify();
    console.log('✅ Teste 3 passou - porta 465 SSL OK');
  } catch (error) {
    console.log('❌ Teste 3 falhou:', error.message);
  }
  
  console.log('\n📝 Possíveis soluções:');
  console.log('1. Verificar se 2FA está ativo na conta Google');
  console.log('2. Gerar novo App Password em: https://myaccount.google.com/apppasswords');
  console.log('3. Verificar se "Acesso a apps menos seguros" está desabilitado');
  console.log('4. Tentar usar outro email ou provedor SMTP');
}

diagnosticTest();