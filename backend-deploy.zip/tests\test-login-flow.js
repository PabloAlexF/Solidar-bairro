const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

async function testarFluxoCompleto() {
  console.log('🧪 Testando fluxo completo: Cadastro + Login\n');
  
  const timestamp = Date.now();
  
  // Dados únicos para teste
  const cidadaoData = {
    nome: 'Teste Login',
    email: `teste.login.${timestamp}@email.com`,
    telefone: '(31) 99999-9999',
    password: '123456',
    cep: '33400-000',
    rua: 'Rua Teste',
    numero: '123',
    bairro: 'Centro',
    cidade: 'Lagoa Santa',
    estado: 'MG'
  };

  try {
    // 1. CADASTRAR CIDADÃO
    console.log('1️⃣ Cadastrando cidadão...');
    const cadastroResponse = await axios.post(`${BASE_URL}/cidadaos`, cidadaoData);
    
    if (cadastroResponse.data.success) {
      console.log('✅ Cidadão cadastrado com sucesso');
      console.log('   ID:', cadastroResponse.data.data.uid);
      console.log('   Email:', cidadaoData.email);
    } else {
      throw new Error('Falha no cadastro');
    }

    // 2. TENTAR LOGIN
    console.log('\n2️⃣ Tentando fazer login...');
    const loginData = {
      email: cidadaoData.email,
      password: cidadaoData.password
    };

    const loginResponse = await axios.post(`${BASE_URL}/auth/login`, loginData);
    
    if (loginResponse.data.success) {
      console.log('✅ Login realizado com sucesso');
      console.log('   Token recebido:', loginResponse.data.token ? 'SIM' : 'NÃO');
      console.log('   Usuário:', loginResponse.data.user?.nome);
      console.log('   Tipo:', loginResponse.data.user?.tipo);
    } else {
      throw new Error('Falha no login');
    }

    // 3. TESTAR TOKEN (se disponível)
    if (loginResponse.data.token) {
      console.log('\n3️⃣ Testando token de autenticação...');
      
      const profileResponse = await axios.get(`${BASE_URL}/auth/profile`, {
        headers: {
          'Authorization': `Bearer ${loginResponse.data.token}`
        }
      });
      
      if (profileResponse.data.success) {
        console.log('✅ Token válido - perfil recuperado');
        console.log('   Nome:', profileResponse.data.user?.nome);
      }
    }

    console.log('\n🎉 FLUXO COMPLETO FUNCIONANDO!');
    
  } catch (error) {
    console.log('\n❌ ERRO no fluxo:');
    console.log('   Status:', error.response?.status);
    console.log('   Erro:', error.response?.data?.error || error.message);
    
    if (error.response?.data) {
      console.log('   Detalhes:', JSON.stringify(error.response.data, null, 2));
    }
  }
}

// Executar teste
testarFluxoCompleto();