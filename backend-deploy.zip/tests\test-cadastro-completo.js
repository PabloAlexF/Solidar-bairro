const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

// Dados de teste para cada categoria
const dadosTeste = {
  cidadao: {
    nome: 'Carlos Eduardo Silva',
    email: 'carlos.silva@email.com',
    telefone: '(31) 98765-4321',
    password: 'senha123',
    cep: '33400-000',
    rua: 'Rua das Acácias',
    numero: '150',
    bairro: 'Centro',
    cidade: 'Lagoa Santa',
    estado: 'MG',
    dataNascimento: '1985-05-15',
    cpf: '123.456.789-00'
  },
  
  comercio: {
    nomeEstabelecimento: 'Mercadinho São José',
    cnpj: '12.345.678/0001-90',
    razaoSocial: 'Mercadinho São José Ltda',
    tipoComercio: 'Alimentação',
    descricaoAtividade: 'Comércio de alimentos e bebidas',
    responsavelNome: 'José Almeida',
    responsavelCpf: '987.654.321-00',
    telefone: '(31) 3333-4444',
    email: 'mercadinho.saojose@email.com',
    senha: 'senha123',
    endereco: 'Av. Principal, 500',
    bairro: 'Centro',
    cidade: 'Lagoa Santa',
    estado: 'MG',
    cep: '33400-000'
  },
  
  ong: {
    nome: 'Instituto Esperança Solidária',
    cnpj: '98.765.432/0001-10',
    email: 'contato@esperancasolidaria.org',
    telefone: '(31) 2222-3333',
    endereco: 'Rua da Solidariedade, 789, Vila Nova, Lagoa Santa',
    areasAtuacao: ['Assistência Social', 'Educação'],
    descricao: 'Apoio a famílias em vulnerabilidade social e educação infantil',
    responsavel: {
      nome: 'Maria Aparecida Santos',
      cpf: '111.222.333-44'
    },
    senha: 'senha123',
    cep: '33400-000',
    bairro: 'Vila Nova',
    cidade: 'Lagoa Santa',
    estado: 'MG'
  },
  
  familia: {
    nomeCompleto: 'Pedro Henrique Costa',
    dataNascimento: '1980-03-20',
    estadoCivil: 'casado',
    profissao: 'Pedreiro',
    cpf: '555.666.777-88',
    rg: '12.345.678-9',
    nis: '12345678901',
    rendaFamiliar: 'ate-1-salario',
    telefone: '(31) 99888-7766',
    whatsapp: '(31) 99888-7766',
    email: 'pedro.costa@email.com',
    password: 'senha123',
    horarioContato: 'manha',
    endereco: 'Rua da Esperança',
    bairro: 'Jardim das Flores',
    pontoReferencia: 'Próximo ao posto de saúde',
    cep: '33400-000',
    numero: '321',
    cidade: 'Lagoa Santa',
    estado: 'MG',
    tipoMoradia: 'alugada',
    criancas: 2,
    jovens: 1,
    adultos: 2,
    idosos: 0,
    necessidades: ['Alimentação Básica', 'Material Escolar', 'Roupas e Calçados'],
    termosAceitos: true
  }
};

async function cadastrarCidadao() {
  console.log('\n👤 === CADASTRANDO CIDADÃO ===');
  try {
    const response = await axios.post(`${BASE_URL}/cidadaos`, dadosTeste.cidadao);
    console.log('✅ Cidadão cadastrado com sucesso!');
    console.log('   ID:', response.data.data.uid);
    console.log('   Nome:', response.data.data.nome);
    console.log('   Email:', response.data.data.email);
    return response.data.data;
  } catch (error) {
    console.error('❌ Erro ao cadastrar cidadão:', error.response?.data?.error || error.message);
    return null;
  }
}

async function cadastrarComercio() {
  console.log('\n🏪 === CADASTRANDO COMÉRCIO ===');
  try {
    const response = await axios.post(`${BASE_URL}/comercios`, dadosTeste.comercio);
    console.log('✅ Comércio cadastrado com sucesso!');
    console.log('   ID:', response.data.data.uid);
    console.log('   Nome:', response.data.data.nomeEstabelecimento);
    console.log('   CNPJ:', response.data.data.cnpj);
    return response.data.data;
  } catch (error) {
    console.error('❌ Erro ao cadastrar comércio:', error.response?.data?.error || error.message);
    return null;
  }
}

async function cadastrarONG() {
  console.log('\n🏛️ === CADASTRANDO ONG ===');
  try {
    const response = await axios.post(`${BASE_URL}/ongs`, dadosTeste.ong);
    console.log('✅ ONG cadastrada com sucesso!');
    console.log('   ID:', response.data.data.uid);
    console.log('   Nome:', response.data.data.nome);
    console.log('   CNPJ:', response.data.data.cnpj);
    return response.data.data;
  } catch (error) {
    console.error('❌ Erro ao cadastrar ONG:', error.response?.data?.error || error.message);
    return null;
  }
}

async function cadastrarFamilia() {
  console.log('\n👨‍👩‍👧‍👦 === CADASTRANDO FAMÍLIA ===');
  try {
    const response = await axios.post(`${BASE_URL}/familias`, dadosTeste.familia);
    console.log('✅ Família cadastrada com sucesso!');
    console.log('   ID:', response.data.data.id);
    console.log('   Responsável:', response.data.data.nomeCompleto);
    console.log('   Membros:', response.data.data.criancas + response.data.data.jovens + response.data.data.adultos + response.data.data.idosos);
    return response.data.data;
  } catch (error) {
    console.error('❌ Erro ao cadastrar família:', error.response?.data?.error || error.message);
    return null;
  }
}

async function cadastrarAchadoPerdido(userId) {
  console.log('\n🔍 === CADASTRANDO ACHADO/PERDIDO ===');
  try {
    const dadosAchado = {
      tipo: 'perdido',
      categoria: 'Documentos',
      titulo: 'Carteira de Identidade Perdida',
      descricao: 'Perdi minha carteira de identidade na região do centro',
      localizacao: {
        endereco: 'Centro, Lagoa Santa - MG',
        latitude: -19.6319,
        longitude: -43.8936
      },
      dataOcorrencia: new Date().toISOString(),
      contato: {
        nome: 'Carlos Eduardo Silva',
        telefone: '(31) 98765-4321',
        email: 'carlos.silva@email.com'
      },
      userId: userId
    };

    const response = await axios.post(`${BASE_URL}/achados-perdidos`, dadosAchado);
    console.log('✅ Item cadastrado com sucesso!');
    console.log('   ID:', response.data.data.id);
    console.log('   Tipo:', response.data.data.tipo);
    console.log('   Título:', response.data.data.titulo);
    return response.data.data;
  } catch (error) {
    console.error('❌ Erro ao cadastrar achado/perdido:', error.response?.data?.error || error.message);
    return null;
  }
}

async function listarTodosCadastros() {
  console.log('\n\n📊 === RESUMO DOS CADASTROS ===\n');
  
  try {
    const cidadaos = await axios.get(`${BASE_URL}/cidadaos`);
    console.log(`👤 Cidadãos: ${cidadaos.data.data.length} cadastrado(s)`);
  } catch (error) {
    console.log('👤 Cidadãos: Erro ao listar');
  }

  try {
    const comercios = await axios.get(`${BASE_URL}/comercios`);
    console.log(`🏪 Comércios: ${comercios.data.data.length} cadastrado(s)`);
  } catch (error) {
    console.log('🏪 Comércios: Erro ao listar');
  }

  try {
    const ongs = await axios.get(`${BASE_URL}/ongs`);
    console.log(`🏛️ ONGs: ${ongs.data.data.length} cadastrada(s)`);
  } catch (error) {
    console.log('🏛️ ONGs: Erro ao listar');
  }

  try {
    const familias = await axios.get(`${BASE_URL}/familias`);
    console.log(`👨‍👩‍👧‍👦 Famílias: ${familias.data.data.length} cadastrada(s)`);
  } catch (error) {
    console.log('👨‍👩‍👧‍👦 Famílias: Erro ao listar');
  }

  try {
    const achados = await axios.get(`${BASE_URL}/achados-perdidos`);
    console.log(`🔍 Achados/Perdidos: ${achados.data.data.length} cadastrado(s)`);
  } catch (error) {
    console.log('🔍 Achados/Perdidos: Erro ao listar');
  }
}

async function executarTeste() {
  console.log('🚀 INICIANDO TESTE DE CADASTRO COMPLETO');
  console.log('=========================================');
  
  // Cadastrar todas as categorias
  const cidadao = await cadastrarCidadao();
  const comercio = await cadastrarComercio();
  const ong = await cadastrarONG();
  const familia = await cadastrarFamilia();
  
  // Cadastrar achado/perdido usando o ID do cidadão
  let achado = null;
  if (cidadao && cidadao.uid) {
    achado = await cadastrarAchadoPerdido(cidadao.uid);
  }
  
  // Listar resumo
  await listarTodosCadastros();
  
  console.log('\n=========================================');
  console.log('✅ TESTE CONCLUÍDO!');
  console.log('=========================================\n');
}

// Executar o teste
if (require.main === module) {
  executarTeste().catch(console.error);
}

module.exports = { executarTeste, dadosTeste };
