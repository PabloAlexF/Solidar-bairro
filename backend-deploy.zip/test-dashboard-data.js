const axios = require('axios');

async function testDashboardMobileData() {
  console.log('📊 TESTE - DADOS DO DASHBOARD MOBILE\n');

  // 1. Verificar Backend
  try {
    const response = await axios.get('http://localhost:3001/health');
    console.log('✅ Backend funcionando:', response.data.status);
  } catch (error) {
    console.log('❌ Backend não está funcionando!');
    return;
  }

  // 2. Buscar dados de todas as APIs
  const apis = [
    { name: 'ONGs', url: '/ongs', icon: '🏛️' },
    { name: 'Comércios', url: '/comercios', icon: '🏪' },
    { name: 'Famílias', url: '/familias', icon: '👨👩👧👦' },
    { name: 'Cidadãos', url: '/cidadaos', icon: '👥' }
  ];

  const dados = {};
  let totalRegistros = 0;
  let totalPendentes = 0;
  let totalAnalisados = 0;

  console.log('\n📋 COLETANDO DADOS DAS APIs...\n');

  for (const api of apis) {
    try {
      const response = await axios.get(`http://localhost:3001/api${api.url}`);
      const data = response.data.data || response.data || [];
      
      const pendentes = data.filter(item => item.status === 'pending' || !item.status).length;
      const analisados = data.filter(item => item.status === 'analyzed').length;
      
      dados[api.name] = {
        total: data.length,
        pendentes: pendentes,
        analisados: analisados,
        dados: data
      };
      
      totalRegistros += data.length;
      totalPendentes += pendentes;
      totalAnalisados += analisados;
      
      console.log(`${api.icon} ${api.name}:`);
      console.log(`   Total: ${data.length}`);
      console.log(`   Pendentes: ${pendentes}`);
      console.log(`   Analisados: ${analisados}`);
      
    } catch (error) {
      console.log(`❌ ${api.name}: Erro na API`);
      dados[api.name] = { total: 0, pendentes: 0, analisados: 0, dados: [] };
    }
  }

  // 3. Resumo geral
  console.log('\n📊 RESUMO GERAL:');
  console.log(`   Total de registros: ${totalRegistros}`);
  console.log(`   Aguardando análise: ${totalPendentes}`);
  console.log(`   Análises concluídas: ${totalAnalisados}`);
  
  const percentualConcluido = totalRegistros > 0 ? Math.round((totalAnalisados / totalRegistros) * 100) : 0;
  console.log(`   Percentual concluído: ${percentualConcluido}%`);

  // 4. Verificar o que deve aparecer no dashboard mobile
  console.log('\n📱 O QUE DEVE APARECER NO DASHBOARD MOBILE:');
  
  console.log('\n   📊 Cards de Estatísticas:');
  console.log(`      🏛️ ONGs: ${dados.ONGs.total}`);
  console.log(`      🏪 Comércios: ${dados.Comércios.total}`);
  console.log(`      👨👩👧👦 Famílias: ${dados.Famílias.total}`);
  console.log(`      👥 Cidadãos: ${dados.Cidadãos.total}`);

  console.log('\n   📈 Meta de Aprovação:');
  console.log(`      Progresso: ${percentualConcluido}%`);
  console.log(`      ${totalAnalisados} de ${totalRegistros} registros analisados`);

  console.log('\n   ⏳ Aguardando Ação:');
  console.log(`      Total pendentes: ${totalPendentes}`);
  
  // Listar itens pendentes por categoria
  Object.keys(dados).forEach(categoria => {
    const cat = dados[categoria];
    if (cat.pendentes > 0) {
      console.log(`      ${categoria}: ${cat.pendentes} pendentes`);
      
      // Mostrar alguns exemplos
      const pendentesExemplos = cat.dados.filter(item => item.status === 'pending' || !item.status).slice(0, 2);
      pendentesExemplos.forEach(item => {
        const nome = item.nome_fantasia || item.nomeCompleto || item.full_name || 'Nome não encontrado';
        console.log(`         - ${nome}`);
      });
    }
  });

  // 5. Gráfico de distribuição
  console.log('\n   📊 Distribuição da Rede (Gráfico):');
  Object.keys(dados).forEach(categoria => {
    const cat = dados[categoria];
    const barra = '█'.repeat(Math.max(1, Math.round(cat.total / 2)));
    console.log(`      ${categoria}: ${barra} (${cat.total})`);
  });

  // 6. Status final
  console.log('\n🎯 STATUS DO DASHBOARD MOBILE:');
  
  if (totalRegistros === 0) {
    console.log('⚠️ Nenhum dado encontrado - Dashboard vazio');
  } else if (totalPendentes === 0) {
    console.log('✅ Excelente! Sem pendências - "Excelente! Sem pendências." deve aparecer');
  } else {
    console.log(`📋 ${totalPendentes} itens aguardando análise - Lista de pendentes deve aparecer`);
  }

  console.log('\n🧪 COMO VERIFICAR NO NAVEGADOR:');
  console.log('1. Acesse: http://localhost:3000/admin');
  console.log('2. Login: joao@teste.com / 123456');
  console.log('3. Ative modo mobile (F12 → Device Toolbar)');
  console.log('4. Vá para aba "Início"');
  console.log('5. Verifique se os números acima aparecem corretamente');

  console.log('\n✅ TESTE DE DADOS CONCLUÍDO!');
}

testDashboardMobileData().catch(console.error);