const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

let authToken = null;

// Fazer login para obter token
async function fazerLogin() {
  try {
    const response = await axios.post(`${BASE_URL}/auth/login`, {
      email: 'carlos.silva@email.com',
      password: 'senha123',
      tipo: 'cidadao'
    });
    authToken = response.data.token;
    console.log('✅ Login realizado com sucesso!');
    return true;
  } catch (error) {
    console.error('❌ Erro no login:', error.response?.data?.error || error.message);
    console.log('\n⚠️  Criando usuário para teste...');
    
    // Tentar criar um usuário para teste
    try {
      await axios.post(`${BASE_URL}/cidadaos`, {
        nome: 'Carlos Silva Teste',
        dataNascimento: '1985-05-15',
        ocupacao: 'Desenvolvedor',
        cpf: '123.456.789-00',
        rg: '12.345.678-9',
        telefone: '(31) 98765-4321',
        email: 'carlos.silva@email.com',
        password: 'senha123',
        cep: '33400-000',
        rua: 'Rua Teste',
        numero: '123',
        bairro: 'Centro',
        cidade: 'Lagoa Santa',
        estado: 'MG'
      });
      console.log('✅ Usuário criado!');
      
      // Tentar login novamente
      const loginResponse = await axios.post(`${BASE_URL}/auth/login`, {
        email: 'carlos.silva@email.com',
        password: 'senha123',
        tipo: 'cidadao'
      });
      authToken = loginResponse.data.token;
      console.log('✅ Login realizado!');
      return true;
    } catch (createError) {
      console.error('❌ Erro ao criar usuário:', createError.response?.data?.error || createError.message);
      return false;
    }
  }
}

// Dados para pedidos de ajuda
const pedidosAjuda = [
  {
    titulo: 'Preciso de alimentos básicos para minha família',
    descricao: 'Estou desempregado e preciso de ajuda com alimentos básicos como arroz, feijão, óleo e macarrão para alimentar meus 3 filhos.',
    categoria: 'Alimentação',
    urgencia: 'alta',
    localizacao: {
      endereco: 'Rua das Flores, 123, Centro, Lagoa Santa - MG',
      latitude: -19.6319,
      longitude: -43.8936
    },
    contato: {
      nome: 'João Silva',
      telefone: '(31) 99999-8888',
      email: 'joao.silva@email.com'
    }
  },
  {
    titulo: 'Necessito de material escolar para meus filhos',
    descricao: 'Meus dois filhos estão começando o ano letivo e preciso de cadernos, lápis, canetas e mochilas.',
    categoria: 'Educação',
    urgencia: 'media',
    localizacao: {
      endereco: 'Av. Principal, 456, Vila Nova, Lagoa Santa - MG',
      latitude: -19.6350,
      longitude: -43.8900
    },
    contato: {
      nome: 'Maria Santos',
      telefone: '(31) 98888-7777',
      email: 'maria.santos@email.com'
    }
  },
  {
    titulo: 'Preciso de remédios para pressão alta',
    descricao: 'Sou idoso e preciso de medicamentos para controle de pressão arterial. Não tenho condições de comprar.',
    categoria: 'Saúde',
    urgencia: 'alta',
    localizacao: {
      endereco: 'Rua da Esperança, 789, Jardim das Flores, Lagoa Santa - MG',
      latitude: -19.6280,
      longitude: -43.8950
    },
    contato: {
      nome: 'José Oliveira',
      telefone: '(31) 97777-6666',
      email: 'jose.oliveira@email.com'
    }
  }
];

// Dados para achados e perdidos
const achadosPerdidos = [
  {
    tipo: 'perdido',
    categoria: 'Documentos',
    titulo: 'Carteira com documentos perdida',
    descricao: 'Perdi minha carteira com RG, CPF e cartões no centro da cidade. É uma carteira marrom de couro.',
    localizacao: {
      endereco: 'Centro, Lagoa Santa - MG',
      latitude: -19.6319,
      longitude: -43.8936
    },
    dataOcorrencia: new Date().toISOString(),
    contato: {
      nome: 'Carlos Pereira',
      telefone: '(31) 99111-2222',
      email: 'carlos.pereira@email.com'
    }
  },
  {
    tipo: 'encontrado',
    categoria: 'Animais',
    titulo: 'Cachorro encontrado na praça',
    descricao: 'Encontrei um cachorro vira-lata de porte médio, cor caramelo, muito dócil. Está com coleira azul.',
    localizacao: {
      endereco: 'Praça Central, Lagoa Santa - MG',
      latitude: -19.6300,
      longitude: -43.8920
    },
    dataOcorrencia: new Date().toISOString(),
    contato: {
      nome: 'Ana Costa',
      telefone: '(31) 98222-3333',
      email: 'ana.costa@email.com'
    }
  },
  {
    tipo: 'perdido',
    categoria: 'Eletrônicos',
    titulo: 'Celular Samsung perdido',
    descricao: 'Perdi meu celular Samsung Galaxy A52 preto com capinha transparente. Tem muitas fotos importantes.',
    localizacao: {
      endereco: 'Av. Central, Lagoa Santa - MG',
      latitude: -19.6330,
      longitude: -43.8910
    },
    dataOcorrencia: new Date().toISOString(),
    contato: {
      nome: 'Pedro Alves',
      telefone: '(31) 97333-4444',
      email: 'pedro.alves@email.com'
    }
  }
];

async function criarPedidosAjuda() {
  console.log('\n🆘 === CRIANDO PEDIDOS DE AJUDA ===\n');
  
  for (let i = 0; i < pedidosAjuda.length; i++) {
    try {
      const response = await axios.post(`${BASE_URL}/pedidos`, pedidosAjuda[i], {
        headers: { Authorization: `Bearer ${authToken}` }
      });
      console.log(`✅ Pedido ${i + 1} criado:`, pedidosAjuda[i].titulo);
      console.log(`   Categoria: ${pedidosAjuda[i].categoria}`);
      console.log(`   Urgência: ${pedidosAjuda[i].urgencia}`);
    } catch (error) {
      console.error(`❌ Erro no pedido ${i + 1}:`, error.response?.data?.error || error.message);
    }
  }
}

async function criarAchadosPerdidos() {
  console.log('\n\n🔍 === CRIANDO ACHADOS E PERDIDOS ===\n');
  
  for (let i = 0; i < achadosPerdidos.length; i++) {
    try {
      const response = await axios.post(`${BASE_URL}/achados-perdidos`, achadosPerdidos[i], {
        headers: { Authorization: `Bearer ${authToken}` }
      });
      console.log(`✅ Item ${i + 1} criado:`, achadosPerdidos[i].titulo);
      console.log(`   Tipo: ${achadosPerdidos[i].tipo}`);
      console.log(`   Categoria: ${achadosPerdidos[i].categoria}`);
    } catch (error) {
      console.error(`❌ Erro no item ${i + 1}:`, error.response?.data?.error || error.message);
    }
  }
}

async function listarResumo() {
  console.log('\n\n📊 === RESUMO ===\n');
  
  try {
    const pedidos = await axios.get(`${BASE_URL}/pedidos`);
    console.log(`🆘 Total de Pedidos de Ajuda: ${pedidos.data.data?.length || 0}`);
  } catch (error) {
    console.log('🆘 Pedidos de Ajuda: Erro ao listar');
  }

  try {
    const achados = await axios.get(`${BASE_URL}/achados-perdidos`);
    console.log(`🔍 Total de Achados/Perdidos: ${achados.data.data?.length || 0}`);
  } catch (error) {
    console.log('🔍 Achados/Perdidos: Erro ao listar');
  }
}

async function executarTeste() {
  console.log('🚀 TESTE DE PEDIDOS E ACHADOS/PERDIDOS');
  console.log('======================================\n');
  
  const loginOk = await fazerLogin();
  if (!loginOk) {
    console.log('\n❌ Não foi possível fazer login. Teste cancelado.');
    return;
  }
  
  await criarPedidosAjuda();
  await criarAchadosPerdidos();
  await listarResumo();
  
  console.log('\n======================================');
  console.log('✅ TESTE CONCLUÍDO!');
  console.log('======================================\n');
}

if (require.main === module) {
  executarTeste().catch(console.error);
}

module.exports = { executarTeste, pedidosAjuda, achadosPerdidos };
