const BotController = require('./src/controllers/botController');

console.log('🧠 Testando Bot Super Inteligente - Análise de Palavras-Chave\n');

// Casos de teste avançados
const advancedTests = [
  {
    name: '🎯 Análise Completa - Família com Crianças',
    data: {
      category: 'Alimentos',
      description: 'Estou desesperado, preciso urgentemente de ajuda com comida para minha família. Somos 5 pessoas: eu, minha esposa e 3 filhos pequenos de 2, 4 e 7 anos. Estou desempregado há 4 meses após ser demitido. Não temos mais dinheiro e as crianças estão com fome. Por favor, qualquer ajuda será muito bem-vinda. Obrigado.',
      urgency: 'critico'
    }
  },
  {
    name: '🏥 Situação Médica - Idoso',
    data: {
      category: 'Medicamentos',
      description: 'Meu avô de 78 anos precisa urgentemente de remédio para o coração. Ele teve um infarto há 2 semanas e está internado no hospital. O médico disse que precisa tomar o medicamento todos os dias, mas não temos dinheiro para comprar. Estamos desesperados.',
      urgency: 'critico'
    }
  },
  {
    name: '💼 Busca por Emprego',
    data: {
      category: 'Serviços',
      description: 'Preciso de ajuda para encontrar trabalho. Tenho experiência como vendedor há 5 anos, mas estou desempregado há 8 meses. Tenho currículo atualizado e estou disposto a trabalhar em qualquer área. Minha família depende de mim.',
      urgency: 'moderada'
    }
  },
  {
    name: '❄️ Inverno - Roupas para Crianças',
    data: {
      category: 'Roupas',
      description: 'Com a chegada do inverno, preciso de agasalhos para meus 2 filhos de 6 e 9 anos. Eles não têm roupas adequadas para o frio e estão passando necessidade. Qualquer doação de roupas de inverno será muito bem-vinda.',
      urgency: 'urgente'
    }
  }
];

console.log('🔍 Executando análises avançadas...\n');

advancedTests.forEach((test, index) => {
  console.log(`${index + 1}. ${test.name}`);
  console.log(`   📝 Descrição: "${test.data.description.substring(0, 80)}..."`);
  
  const result = BotController.validateRequestIntelligent(test.data);
  
  console.log(`   📊 Resultado: ${result.isValid ? '✅ APROVADO' : '❌ REJEITADO'}`);
  console.log(`   🎯 Confiança: ${result.confidence}%`);
  console.log(`   📈 Score de Risco: ${result.riskScore}`);
  console.log(`   💭 Análise: ${result.analysis}`);
  
  // Mostrar análise de palavras-chave
  const keywords = result.keywords;
  const sentiment = result.sentiment;
  
  console.log(`   🔑 Palavras-chave encontradas:`);
  
  // Urgência
  if (keywords.urgency.critical.length > 0) {
    console.log(`      🚨 Críticas: ${keywords.urgency.critical.join(', ')}`);
  }
  if (keywords.urgency.moderate.length > 0) {
    console.log(`      ⚠️  Moderadas: ${keywords.urgency.moderate.join(', ')}`);
  }
  
  // Família
  if (keywords.family.children.length > 0) {
    console.log(`      👶 Crianças: ${keywords.family.children.join(', ')}`);
  }
  if (keywords.family.elderly.length > 0) {
    console.log(`      👴 Idosos: ${keywords.family.elderly.join(', ')}`);
  }
  if (keywords.family.family.length > 0) {
    console.log(`      👨‍👩‍👧‍👦 Família: ${keywords.family.family.join(', ')}`);
  }
  
  // Situação
  if (keywords.situation.unemployment.length > 0) {
    console.log(`      💼 Desemprego: ${keywords.situation.unemployment.join(', ')}`);
  }
  if (keywords.situation.health.length > 0) {
    console.log(`      🏥 Saúde: ${keywords.situation.health.join(', ')}`);
  }
  if (keywords.situation.financial.length > 0) {
    console.log(`      💰 Financeiro: ${keywords.situation.financial.join(', ')}`);
  }
  
  // Emoções
  if (keywords.emotion.desperation.length > 0) {
    console.log(`      😰 Desespero: ${keywords.emotion.desperation.join(', ')}`);
  }
  if (keywords.emotion.gratitude.length > 0) {
    console.log(`      🙏 Gratidão: ${keywords.emotion.gratitude.join(', ')}`);
  }
  
  console.log(`   📊 Análise de Sentimento:`);
  console.log(`      💔 Score Emocional: ${Math.round(sentiment.score * 100)}%`);
  console.log(`      ✅ Autenticidade: ${Math.round(sentiment.authenticity * 100)}%`);
  console.log(`      🔢 Total de Palavras-chave: ${sentiment.totalKeywords}`);
  
  if (result.suggestions.length > 0) {
    console.log(`   💡 Sugestões: ${result.suggestions.join('; ')}`);
  }
  
  console.log('');
});

console.log('🎉 Análise avançada de palavras-chave implementada com sucesso!');
console.log('🧠 O bot agora é capaz de:');
console.log('   • Detectar contexto emocional');
console.log('   • Identificar situações familiares');
console.log('   • Avaliar autenticidade por detalhes específicos');
console.log('   • Analisar coerência entre urgência e palavras-chave');
console.log('   • Priorizar casos com crianças e idosos');
console.log('   • Detectar situações de desemprego e saúde');