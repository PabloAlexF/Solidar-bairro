const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

async function testarFluxoFinal() {
  console.log('🎯 TESTE FINAL COMPLETO: Cadastro + Login + Verificação\n');
  
  const timestamp = Date.now();
  
  // Dados únicos para teste
  const cidadaoData = {
    nome: 'Usuario Final',
    email: `usuario.final.${timestamp}@email.com`,
    telefone: '(31) 99999-9999',
    password: '123456',
    cep: '33400-000',
    rua: 'Rua Final',
    numero: '123',
    bairro: 'Centro',
    cidade: 'Lagoa Santa',
    estado: 'MG'
  };

  try {
    // 1. CADASTRAR CIDADÃO
    console.log('1️⃣ CADASTRANDO CIDADÃO...');
    const cadastroResponse = await axios.post(`${BASE_URL}/cidadaos`, cidadaoData);
    
    if (cadastroResponse.data.success) {
      console.log('✅ Cidadão cadastrado com sucesso');
      console.log('   ID:', cadastroResponse.data.data.id);
      console.log('   Nome:', cadastroResponse.data.data.nome);
      console.log('   Email:', cadastroResponse.data.data.email);
    }

    // 2. FAZER LOGIN
    console.log('\n2️⃣ FAZENDO LOGIN...');
    const loginData = {
      email: cidadaoData.email,
      password: cidadaoData.password
    };

    const loginResponse = await axios.post(`${BASE_URL}/auth/login`, loginData);
    
    if (loginResponse.data.success) {
      console.log('✅ Login realizado com sucesso');
      console.log('   Token gerado:', !!loginResponse.data.data.token);
      console.log('   Refresh token:', !!loginResponse.data.data.refreshToken);
      console.log('   Nome do usuário:', loginResponse.data.data.user.nome);
      console.log('   Tipo:', loginResponse.data.data.user.tipo);
    }

    // 3. VERIFICAR TOKEN
    console.log('\n3️⃣ VERIFICANDO TOKEN...');
    const token = loginResponse.data.data.token;
    
    const verifyResponse = await axios.post(`${BASE_URL}/auth/verify`, {}, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (verifyResponse.data.success) {
      console.log('✅ Token válido');
      console.log('   Usuário autenticado:', verifyResponse.data.data.nome || verifyResponse.data.data.email);
    }

    // 4. TESTAR REFRESH TOKEN
    console.log('\n4️⃣ TESTANDO REFRESH TOKEN...');
    const refreshToken = loginResponse.data.data.refreshToken;
    
    const refreshResponse = await axios.post(`${BASE_URL}/auth/refresh`, {
      refreshToken: refreshToken
    });
    
    if (refreshResponse.data.success) {
      console.log('✅ Refresh token funcionando');
      console.log('   Novo token gerado:', !!refreshResponse.data.data.token);
    }

    console.log('\n🎉 TODOS OS TESTES PASSARAM!');
    console.log('✅ Cadastro funcionando');
    console.log('✅ Login funcionando');
    console.log('✅ Autenticação funcionando');
    console.log('✅ Refresh token funcionando');
    
  } catch (error) {
    console.log('\n❌ ERRO no teste:');
    console.log('Status:', error.response?.status);
    console.log('Erro:', error.response?.data?.error || error.message);
    
    if (error.response?.data) {
      console.log('Detalhes:', JSON.stringify(error.response.data, null, 2));
    }
  }
}

testarFluxoFinal();