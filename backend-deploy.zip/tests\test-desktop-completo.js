const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

const dadosDesktop = {
  cidadao: {
    nome: 'Marcos Antonio Pereira',
    dataNascimento: '1982-04-18',
    ocupacao: 'Engenheiro Civil',
    cpf: '888.999.000-11',
    rg: '56.789.012-3',
    telefone: '(31) 99111-2222',
    email: 'marcos.pereira@email.com',
    password: 'senha123',
    cep: '33400-000',
    rua: 'Rua das Orquídeas',
    numero: '890',
    bairro: 'Jardim Europa',
    cidade: 'Lagoa Santa',
    estado: 'MG',
    referencia: 'Próximo ao supermercado',
    disponibilidade: ['Finais de semana', 'Período da tarde'],
    interesses: ['Reparos e Reformas', 'Logística e Transporte'],
    proposito: 'Quero usar minhas habilidades de engenharia para ajudar a comunidade'
  },

  comercio: {
    nomeComercio: 'Supermercado Bom Preço',
    cnpj: '22.333.444/0001-55',
    categoria: 'alimentacao',
    responsavel: 'Sandra Regina Oliveira',
    senha: 'senha123',
    telefone: '(31) 3366-7788',
    email: 'supermercado.bompreco@email.com',
    endereco: 'Av. Principal, 2500, Centro, Lagoa Santa - MG',
    horarioFuncionamento: 'Segunda a Sábado das 07h às 22h, Domingo das 08h às 18h',
    descricao: 'Supermercado de bairro com produtos variados e preços acessíveis'
  },

  ong: {
    nome: 'Instituto Crescer Juntos',
    cnpj: '66.777.888/0001-99',
    email: 'contato@crescerjuntos.org',
    telefone: '(31) 3377-8899',
    senha: 'senha123',
    cep: '33400-000',
    endereco: 'Rua da Esperança, 123, Vila Esperança, Lagoa Santa - MG',
    areasAtuacao: ['Educação', 'Cultura', 'Esporte'],
    descricao: 'ONG focada no desenvolvimento educacional e cultural de crianças e adolescentes',
    responsavel: {
      nome: 'Paulo Roberto Silva',
      cpf: '444.555.666-77'
    }
  },

  familia: {
    nomeCompleto: 'Carla Souza Mendes',
    dataNascimento: '1992-09-14',
    estadoCivil: 'casado',
    profissao: 'Auxiliar de Limpeza',
    cpf: '777.888.999-00',
    rg: '67.890.123-4',
    nis: '22233344455',
    rendaFamiliar: 'ate-2-salarios',
    telefone: '(31) 99333-4444',
    whatsapp: '(31) 99333-4444',
    email: 'carla.mendes@email.com',
    password: 'senha123',
    confirmPassword: 'senha123',
    horarioContato: 'tarde',
    cep: '33400-000',
    endereco: 'Rua das Margaridas',
    numero: '678',
    bairro: 'Jardim Primavera',
    cidade: 'Lagoa Santa',
    estado: 'MG',
    pontoReferencia: 'Ao lado da igreja',
    tipoMoradia: 'propria',
    criancas: 3,
    jovens: 1,
    adultos: 2,
    idosos: 0,
    necessidades: ['Alimentação Básica', 'Material Escolar', 'Medicamentos', 'Roupas e Calçados'],
    termosAceitos: true
  }
};

async function testarCidadaoDesktop() {
  console.log('\n🖥️  === CIDADÃO DESKTOP ===');
  try {
    const response = await axios.post(`${BASE_URL}/cidadaos`, dadosDesktop.cidadao);
    console.log('✅ Cadastrado:', response.data.data.nome);
    console.log('   Email:', response.data.data.email);
    return response.data.data;
  } catch (error) {
    console.error('❌ Erro:', error.response?.data?.error || error.message);
    return null;
  }
}

async function testarComercioDesktop() {
  console.log('\n🖥️  === COMÉRCIO DESKTOP ===');
  try {
    const response = await axios.post(`${BASE_URL}/comercios`, dadosDesktop.comercio);
    console.log('✅ Cadastrado:', response.data.data.nomeComercio);
    console.log('   CNPJ:', response.data.data.cnpj);
    return response.data.data;
  } catch (error) {
    console.error('❌ Erro:', error.response?.data?.error || error.message);
    return null;
  }
}

async function testarONGDesktop() {
  console.log('\n🖥️  === ONG DESKTOP ===');
  try {
    const response = await axios.post(`${BASE_URL}/ongs`, dadosDesktop.ong);
    console.log('✅ Cadastrada:', response.data.data.nome);
    console.log('   CNPJ:', response.data.data.cnpj);
    return response.data.data;
  } catch (error) {
    console.error('❌ Erro:', error.response?.data?.error || error.message);
    return null;
  }
}

async function testarFamiliaDesktop() {
  console.log('\n🖥️  === FAMÍLIA DESKTOP ===');
  try {
    const response = await axios.post(`${BASE_URL}/familias`, dadosDesktop.familia);
    console.log('✅ Cadastrada:', response.data.data.nomeCompleto);
    const totalMembros = dadosDesktop.familia.criancas + dadosDesktop.familia.jovens + 
                         dadosDesktop.familia.adultos + dadosDesktop.familia.idosos;
    console.log('   Membros:', totalMembros);
    console.log('   Necessidades:', response.data.data.necessidades.length);
    return response.data.data;
  } catch (error) {
    console.error('❌ Erro:', error.response?.data?.error || error.message);
    return null;
  }
}

async function executarTesteDesktop() {
  console.log('🖥️  TESTE CADASTROS DESKTOP');
  console.log('===========================\n');
  
  await testarCidadaoDesktop();
  await testarComercioDesktop();
  await testarONGDesktop();
  await testarFamiliaDesktop();
  
  console.log('\n===========================');
  console.log('✅ TESTE DESKTOP CONCLUÍDO!');
  console.log('===========================\n');
}

if (require.main === module) {
  executarTesteDesktop().catch(console.error);
}

module.exports = { executarTesteDesktop, dadosDesktop };
