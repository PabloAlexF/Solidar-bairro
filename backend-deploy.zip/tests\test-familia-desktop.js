const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

// Dados completos simulando o preenchimento do formulário desktop
const dadosFormularioDesktop = {
  // Step 1: Responsável
  nomeCompleto: 'Ana Paula Oliveira',
  dataNascimento: '1988-07-12',
  estadoCivil: 'casado',
  profissao: 'Diarista',
  
  // Step 2: Documentos
  cpf: '444.555.666-77',
  rg: '23.456.789-1',
  nis: '98765432109',
  rendaFamiliar: 'ate-2-salarios',
  
  // Step 3: Contato
  telefone: '(31) 99777-6655',
  whatsapp: '(31) 99777-6655',
  email: 'ana.oliveira@email.com',
  password: 'senha123',
  confirmPassword: 'senha123',
  horarioContato: 'tarde',
  
  // Step 4: Residência
  cep: '33400-000',
  endereco: 'Rua das Palmeiras',
  numero: '245',
  bairro: 'Jardim Primavera',
  cidade: 'Lagoa Santa',
  estado: 'MG',
  pontoReferencia: 'Ao lado da escola municipal',
  tipoMoradia: 'propria',
  
  // Step 5: Família
  criancas: 3,
  jovens: 1,
  adultos: 2,
  idosos: 1,
  
  // Step 6: Necessidades
  necessidades: [
    'Alimentação Básica',
    'Medicamentos',
    'Material Escolar',
    'Roupas e Calçados'
  ],
  
  // Termos
  termosAceitos: true
};

async function testarCadastroFamiliaDesktop() {
  console.log('🖥️  TESTE DE CADASTRO - FAMÍLIA DESKTOP');
  console.log('==========================================\n');
  
  console.log('📋 Dados do Formulário:');
  console.log('------------------------');
  console.log('Step 1 - Responsável:');
  console.log(`  Nome: ${dadosFormularioDesktop.nomeCompleto}`);
  console.log(`  Data Nascimento: ${dadosFormularioDesktop.dataNascimento}`);
  console.log(`  Estado Civil: ${dadosFormularioDesktop.estadoCivil}`);
  console.log(`  Profissão: ${dadosFormularioDesktop.profissao}`);
  
  console.log('\nStep 2 - Documentos:');
  console.log(`  CPF: ${dadosFormularioDesktop.cpf}`);
  console.log(`  RG: ${dadosFormularioDesktop.rg}`);
  console.log(`  NIS: ${dadosFormularioDesktop.nis}`);
  console.log(`  Renda Familiar: ${dadosFormularioDesktop.rendaFamiliar}`);
  
  console.log('\nStep 3 - Contato:');
  console.log(`  Telefone: ${dadosFormularioDesktop.telefone}`);
  console.log(`  WhatsApp: ${dadosFormularioDesktop.whatsapp}`);
  console.log(`  Email: ${dadosFormularioDesktop.email}`);
  console.log(`  Horário Contato: ${dadosFormularioDesktop.horarioContato}`);
  
  console.log('\nStep 4 - Residência:');
  console.log(`  CEP: ${dadosFormularioDesktop.cep}`);
  console.log(`  Endereço: ${dadosFormularioDesktop.endereco}, ${dadosFormularioDesktop.numero}`);
  console.log(`  Bairro: ${dadosFormularioDesktop.bairro}`);
  console.log(`  Cidade: ${dadosFormularioDesktop.cidade}/${dadosFormularioDesktop.estado}`);
  console.log(`  Tipo Moradia: ${dadosFormularioDesktop.tipoMoradia}`);
  
  console.log('\nStep 5 - Família:');
  console.log(`  Crianças (0-12): ${dadosFormularioDesktop.criancas}`);
  console.log(`  Jovens (13-17): ${dadosFormularioDesktop.jovens}`);
  console.log(`  Adultos (18-59): ${dadosFormularioDesktop.adultos}`);
  console.log(`  Idosos (60+): ${dadosFormularioDesktop.idosos}`);
  const totalMembros = dadosFormularioDesktop.criancas + dadosFormularioDesktop.jovens + 
                       dadosFormularioDesktop.adultos + dadosFormularioDesktop.idosos;
  console.log(`  Total de Membros: ${totalMembros}`);
  
  console.log('\nStep 6 - Necessidades:');
  dadosFormularioDesktop.necessidades.forEach(n => console.log(`  ✓ ${n}`));
  
  console.log('\n\n🚀 Enviando cadastro para API...\n');
  
  try {
    const response = await axios.post(`${BASE_URL}/familias`, dadosFormularioDesktop);
    
    console.log('✅ CADASTRO REALIZADO COM SUCESSO!');
    console.log('==================================\n');
    console.log('📄 Dados Retornados:');
    console.log(`  ID: ${response.data.data.id}`);
    console.log(`  Responsável: ${response.data.data.nomeCompleto}`);
    console.log(`  Email: ${response.data.data.email}`);
    console.log(`  CPF: ${response.data.data.cpf}`);
    console.log(`  Total Membros: ${totalMembros}`);
    console.log(`  Necessidades: ${response.data.data.necessidades.length} itens`);
    console.log(`  Status: ${response.data.data.status || 'Ativo'}`);
    console.log(`  Data Cadastro: ${response.data.data.dataCadastro || new Date().toISOString()}`);
    
    // Verificar se foi cadastrado
    console.log('\n\n🔍 Verificando cadastro...\n');
    const verificacao = await axios.get(`${BASE_URL}/familias/${response.data.data.id}`);
    
    if (verificacao.data.success) {
      console.log('✅ Família encontrada no banco de dados!');
      console.log(`   Nome: ${verificacao.data.data.nomeCompleto}`);
      console.log(`   Endereço: ${verificacao.data.data.endereco}, ${verificacao.data.data.numero}`);
      console.log(`   Bairro: ${verificacao.data.data.bairro}`);
    }
    
    // Listar todas as famílias
    console.log('\n\n📊 Total de Famílias Cadastradas:\n');
    const lista = await axios.get(`${BASE_URL}/familias`);
    console.log(`   Total: ${lista.data.data.length} família(s)`);
    
    console.log('\n==========================================');
    console.log('✅ TESTE CONCLUÍDO COM SUCESSO!');
    console.log('==========================================\n');
    
    return response.data.data;
    
  } catch (error) {
    console.error('\n❌ ERRO NO CADASTRO!');
    console.error('====================\n');
    
    if (error.response) {
      console.error('Status:', error.response.status);
      console.error('Erro:', error.response.data.error);
      console.error('Detalhes:', error.response.data.details || 'Nenhum detalhe adicional');
    } else {
      console.error('Erro:', error.message);
    }
    
    console.log('\n==========================================\n');
    return null;
  }
}

// Executar o teste
if (require.main === module) {
  testarCadastroFamiliaDesktop().catch(console.error);
}

module.exports = { testarCadastroFamiliaDesktop, dadosFormularioDesktop };
