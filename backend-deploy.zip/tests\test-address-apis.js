const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

async function testarAPIsEndereco() {
  console.log('🏠 Testando APIs de Endereço\n');

  try {
    // 1. Testar busca por CEP
    console.log('1️⃣ Testando busca por CEP...');
    const cepResponse = await axios.get(`${BASE_URL}/address/cep/33400000`);
    
    if (cepResponse.data.success) {
      console.log('✅ CEP encontrado:');
      console.log('   Logradouro:', cepResponse.data.data.logradouro);
      console.log('   Bairro:', cepResponse.data.data.bairro);
      console.log('   Cidade:', cepResponse.data.data.cidade);
      console.log('   Estado:', cepResponse.data.data.estado);
    }

    // 2. Testar busca por endereço
    console.log('\n2️⃣ Testando busca por endereço...');
    const addressResponse = await axios.get(`${BASE_URL}/address/search`, {
      params: {
        uf: 'MG',
        cidade: 'Lagoa Santa',
        logradouro: 'Rua'
      }
    });
    
    if (addressResponse.data.success) {
      console.log('✅ Endereços encontrados:', addressResponse.data.data.length);
      if (addressResponse.data.data.length > 0) {
        console.log('   Primeiro resultado:', addressResponse.data.data[0].logradouro);
      }
    }

    // 3. Testar busca de bairros
    console.log('\n3️⃣ Testando busca de bairros...');
    const neighborhoodsResponse = await axios.get(`${BASE_URL}/address/neighborhoods`, {
      params: {
        uf: 'MG',
        cidade: 'Lagoa Santa'
      }
    });
    
    if (neighborhoodsResponse.data.success) {
      console.log('✅ Bairros encontrados:', neighborhoodsResponse.data.data.length);
      if (neighborhoodsResponse.data.data.length > 0) {
        console.log('   Exemplos:', neighborhoodsResponse.data.data.slice(0, 3).join(', '));
      }
    }

    console.log('\n🎉 Todas as APIs de endereço funcionando!');

  } catch (error) {
    console.log('\n❌ Erro ao testar APIs:');
    console.log('Status:', error.response?.status);
    console.log('Erro:', error.response?.data?.error || error.message);
  }
}

testarAPIsEndereco();