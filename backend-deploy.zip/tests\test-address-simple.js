const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

async function testAddressAPIs() {
  console.log('🏠 TESTANDO APIs DE ENDEREÇO\n');
  
  const tests = [
    {
      name: 'Health Check',
      url: 'http://localhost:3001/health',
      method: 'GET'
    },
    {
      name: 'CEP - Avenida Paulista',
      url: `${BASE_URL}/address/cep/01310100`,
      method: 'GET'
    },
    {
      name: 'Busca por Endereço',
      url: `${BASE_URL}/address/search?uf=SP&cidade=São Paulo&logradouro=Avenida Paulista`,
      method: 'GET'
    },
    {
      name: 'Bairros de São Paulo',
      url: `${BASE_URL}/address/neighborhoods?uf=SP&cidade=São Paulo`,
      method: 'GET'
    }
  ];

  for (const test of tests) {
    try {
      console.log(`🔍 Testando: ${test.name}`);
      const response = await axios.get(test.url);
      console.log(`✅ ${test.name}: Status ${response.status}`);
      
      if (test.name.includes('CEP')) {
        console.log(`   📍 Endereço: ${response.data.logradouro}, ${response.data.bairro}`);
      }
      
    } catch (error) {
      if (error.response) {
        console.log(`❌ ${test.name}: ${error.response.status} - ${error.response.data?.error || error.response.statusText}`);
      } else {
        console.log(`❌ ${test.name}: ${error.message}`);
      }
    }
    
    // Pequena pausa entre requisições
    await new Promise(resolve => setTimeout(resolve, 100));
  }

  console.log('\n📋 RESUMO DAS APIs DE ENDEREÇO:');
  console.log('• GET /api/address/cep/:cep - Buscar por CEP');
  console.log('• GET /api/address/search - Buscar por endereço');
  console.log('• GET /api/address/neighborhoods - Listar bairros');
  console.log('\n🔧 Rate Limits Atualizados:');
  console.log('• Geral: 1000 req/15min');
  console.log('• Endereços: 500 req/15min');
  console.log('• CEP: 100 req/10min');
}

testAddressAPIs().catch(console.error);