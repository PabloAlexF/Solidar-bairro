require('dotenv').config();
const emailService = require('./src/services/emailService');

async function testEmail() {
  console.log('🧪 Testando envio de email...');
  
  try {
    // Testar código de confirmação
    const result = await emailService.sendConfirmationCode('renatobcdesign@gmail.com', '123456');
    console.log('✅ Teste bem-sucedido:', result);
  } catch (error) {
    console.error('❌ Erro no teste:', error.message);
    console.error('Stack:', error.stack);
  }
}

testEmail();