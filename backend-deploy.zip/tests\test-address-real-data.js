const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

// Real Brazilian addresses for testing
const TEST_DATA = {
  ceps: [
    { cep: '01310-100', expected: { cidade: 'São Paulo', estado: 'SP', bairro: 'Bela Vista' } },
    { cep: '20040-020', expected: { cidade: 'Rio de Janeiro', estado: 'RJ', bairro: 'Centro' } },
    { cep: '30112-000', expected: { cidade: 'Belo Horizonte', estado: 'MG', bairro: 'Centro' } },
    { cep: '33400-000', expected: { cidade: 'Lagoa Santa', estado: 'MG' } },
    { cep: '80010-000', expected: { cidade: 'Curitiba', estado: 'PR', bairro: 'Centro' } },
    { cep: '40070-110', expected: { cidade: 'Salvador', estado: 'BA', bairro: 'Pelourinho' } },
    { cep: '60160-230', expected: { cidade: 'Fortaleza', estado: 'CE', bairro: 'Centro' } },
    { cep: '50030-230', expected: { cidade: 'Recife', estado: 'PE', bairro: 'Boa Vista' } }
  ],
  addresses: [
    { uf: 'SP', cidade: 'São Paulo', logradouro: 'Avenida Paulista' },
    { uf: 'RJ', cidade: 'Rio de Janeiro', logradouro: 'Rua das Flores' },
    { uf: 'MG', cidade: 'Belo Horizonte', logradouro: 'Rua da Bahia' },
    { uf: 'MG', cidade: 'Lagoa Santa', logradouro: 'Rua' },
    { uf: 'PR', cidade: 'Curitiba', logradouro: 'Rua XV de Novembro' },
    { uf: 'BA', cidade: 'Salvador', logradouro: 'Rua Chile' },
    { uf: 'CE', cidade: 'Fortaleza', logradouro: 'Rua Major Facundo' },
    { uf: 'PE', cidade: 'Recife', logradouro: 'Rua do Bom Jesus' }
  ],
  neighborhoods: [
    { uf: 'SP', cidade: 'São Paulo' },
    { uf: 'RJ', cidade: 'Rio de Janeiro' },
    { uf: 'MG', cidade: 'Belo Horizonte' },
    { uf: 'MG', cidade: 'Lagoa Santa' },
    { uf: 'PR', cidade: 'Curitiba' }
  ]
};

async function testCepSearch() {
  console.log('🔍 Testando busca por CEP com dados reais...\n');
  
  let successCount = 0;
  let totalTests = TEST_DATA.ceps.length;

  for (const testCase of TEST_DATA.ceps) {
    try {
      console.log(`📍 Testando CEP: ${testCase.cep}`);
      const response = await axios.get(`${BASE_URL}/address/cep/${testCase.cep}`);
      
      if (response.data.success) {
        const data = response.data.data;
        console.log(`   ✅ Encontrado: ${data.logradouro || 'N/A'}, ${data.bairro || 'N/A'}, ${data.cidade}, ${data.estado}`);
        
        // Validate expected data
        if (testCase.expected.cidade && data.cidade !== testCase.expected.cidade) {
          console.log(`   ⚠️  Cidade esperada: ${testCase.expected.cidade}, recebida: ${data.cidade}`);
        }
        if (testCase.expected.estado && data.estado !== testCase.expected.estado) {
          console.log(`   ⚠️  Estado esperado: ${testCase.expected.estado}, recebido: ${data.estado}`);
        }
        
        successCount++;
      } else {
        console.log(`   ❌ Falha: ${response.data.error}`);
      }
    } catch (error) {
      console.log(`   ❌ Erro: ${error.response?.data?.error || error.message}`);
    }
    console.log('');
  }

  console.log(`📊 Resultado CEP: ${successCount}/${totalTests} sucessos\n`);
  return successCount === totalTests;
}

async function testAddressSearch() {
  console.log('🏠 Testando busca por endereço com dados reais...\n');
  
  let successCount = 0;
  let totalTests = TEST_DATA.addresses.length;

  for (const testCase of TEST_DATA.addresses) {
    try {
      console.log(`📍 Testando: ${testCase.logradouro} em ${testCase.cidade}/${testCase.uf}`);
      const response = await axios.get(`${BASE_URL}/address/search`, {
        params: testCase
      });
      
      if (response.data.success) {
        const results = response.data.data;
        console.log(`   ✅ Encontrados: ${results.length} endereços`);
        
        if (results.length > 0) {
          console.log(`   📋 Exemplos:`);
          results.slice(0, 3).forEach((addr, index) => {
            console.log(`      ${index + 1}. ${addr.logradouro}, ${addr.bairro}, CEP: ${addr.cep}`);
          });
        }
        
        successCount++;
      } else {
        console.log(`   ❌ Falha: ${response.data.error}`);
      }
    } catch (error) {
      console.log(`   ❌ Erro: ${error.response?.data?.error || error.message}`);
    }
    console.log('');
  }

  console.log(`📊 Resultado Endereços: ${successCount}/${totalTests} sucessos\n`);
  return successCount === totalTests;
}

async function testNeighborhoodSearch() {
  console.log('🏘️ Testando busca de bairros com dados reais...\n');
  
  let successCount = 0;
  let totalTests = TEST_DATA.neighborhoods.length;

  for (const testCase of TEST_DATA.neighborhoods) {
    try {
      console.log(`📍 Testando bairros de: ${testCase.cidade}/${testCase.uf}`);
      const response = await axios.get(`${BASE_URL}/address/neighborhoods`, {
        params: testCase
      });
      
      if (response.data.success) {
        const neighborhoods = response.data.data;
        console.log(`   ✅ Encontrados: ${neighborhoods.length} bairros`);
        
        if (neighborhoods.length > 0) {
          console.log(`   📋 Exemplos: ${neighborhoods.slice(0, 5).join(', ')}`);
        }
        
        successCount++;
      } else {
        console.log(`   ❌ Falha: ${response.data.error}`);
      }
    } catch (error) {
      console.log(`   ❌ Erro: ${error.response?.data?.error || error.message}`);
    }
    console.log('');
  }

  console.log(`📊 Resultado Bairros: ${successCount}/${totalTests} sucessos\n`);
  return successCount === totalTests;
}

async function testInvalidData() {
  console.log('🚫 Testando dados inválidos...\n');
  
  const invalidTests = [
    { name: 'CEP inválido (muito curto)', test: () => axios.get(`${BASE_URL}/address/cep/123`) },
    { name: 'CEP inválido (não existe)', test: () => axios.get(`${BASE_URL}/address/cep/99999999`) },
    { name: 'Busca sem parâmetros', test: () => axios.get(`${BASE_URL}/address/search`) },
    { name: 'Logradouro muito curto', test: () => axios.get(`${BASE_URL}/address/search?uf=SP&cidade=São Paulo&logradouro=A`) },
    { name: 'Cidade inexistente', test: () => axios.get(`${BASE_URL}/address/search?uf=SP&cidade=CidadeInexistente&logradouro=Rua`) }
  ];

  let errorCount = 0;
  
  for (const invalidTest of invalidTests) {
    try {
      console.log(`🧪 ${invalidTest.name}`);
      await invalidTest.test();
      console.log(`   ⚠️  Deveria ter falhado mas passou`);
    } catch (error) {
      if (error.response?.status >= 400) {
        console.log(`   ✅ Falhou corretamente: ${error.response.data.error}`);
        errorCount++;
      } else {
        console.log(`   ❌ Erro inesperado: ${error.message}`);
      }
    }
  }

  console.log(`📊 Validação de erros: ${errorCount}/${invalidTests.length} corretos\n`);
  return errorCount === invalidTests.length;
}

async function testPerformance() {
  console.log('⚡ Testando performance das APIs...\n');
  
  const performanceTests = [
    {
      name: 'Busca por CEP',
      test: () => axios.get(`${BASE_URL}/address/cep/01310100`)
    },
    {
      name: 'Busca por endereço',
      test: () => axios.get(`${BASE_URL}/address/search?uf=SP&cidade=São Paulo&logradouro=Avenida`)
    },
    {
      name: 'Busca de bairros',
      test: () => axios.get(`${BASE_URL}/address/neighborhoods?uf=SP&cidade=São Paulo`)
    }
  ];

  for (const perfTest of performanceTests) {
    const startTime = Date.now();
    try {
      await perfTest.test();
      const endTime = Date.now();
      const duration = endTime - startTime;
      console.log(`⏱️  ${perfTest.name}: ${duration}ms`);
      
      if (duration > 5000) {
        console.log(`   ⚠️  Resposta lenta (>5s)`);
      } else if (duration > 2000) {
        console.log(`   ⚠️  Resposta moderada (>2s)`);
      } else {
        console.log(`   ✅ Resposta rápida`);
      }
    } catch (error) {
      console.log(`   ❌ Erro: ${error.message}`);
    }
  }
  console.log('');
}

async function runAllTests() {
  console.log('🚀 Iniciando testes completos das APIs de Endereço\n');
  console.log('=' .repeat(60));
  
  const results = {
    cep: await testCepSearch(),
    address: await testAddressSearch(),
    neighborhoods: await testNeighborhoodSearch(),
    validation: await testInvalidData()
  };
  
  await testPerformance();
  
  console.log('=' .repeat(60));
  console.log('📋 RESUMO DOS TESTES:');
  console.log(`   CEP Search: ${results.cep ? '✅ PASSOU' : '❌ FALHOU'}`);
  console.log(`   Address Search: ${results.address ? '✅ PASSOU' : '❌ FALHOU'}`);
  console.log(`   Neighborhoods: ${results.neighborhoods ? '✅ PASSOU' : '❌ FALHOU'}`);
  console.log(`   Validation: ${results.validation ? '✅ PASSOU' : '❌ FALHOU'}`);
  
  const allPassed = Object.values(results).every(result => result);
  console.log(`\n🎯 RESULTADO GERAL: ${allPassed ? '✅ TODOS OS TESTES PASSARAM' : '❌ ALGUNS TESTES FALHARAM'}`);
  
  if (allPassed) {
    console.log('\n🎉 As APIs de endereço estão funcionando perfeitamente com dados reais!');
  } else {
    console.log('\n⚠️  Algumas APIs precisam de atenção. Verifique os logs acima.');
  }
}

// Execute tests
runAllTests().catch(error => {
  console.error('❌ Erro fatal nos testes:', error.message);
  process.exit(1);
});