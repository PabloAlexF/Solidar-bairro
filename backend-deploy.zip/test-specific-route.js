const axios = require('axios');

async function testSpecificRoute() {
  console.log('🔧 TESTE RÁPIDO - ROTA ESPECÍFICA\n');

  const API_BASE = 'http://localhost:3001/api';

  // 1. Login
  let token = null;
  try {
    const loginResponse = await axios.post(`${API_BASE}/auth/login`, {
      email: 'joao@teste.com',
      password: '123456'
    });
    token = loginResponse.data.token;
    console.log('✅ Login realizado');
  } catch (error) {
    console.log('❌ Erro no login');
    return;
  }

  const authHeaders = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  };

  // 2. Buscar um cidadão
  try {
    const cidadaosResponse = await axios.get(`${API_BASE}/cidadaos`, { headers: authHeaders });
    const cidadaos = cidadaosResponse.data.data || cidadaosResponse.data || [];
    
    if (cidadaos.length > 0) {
      const testCidadao = cidadaos[0];
      console.log(`📋 Cidadão encontrado: ${testCidadao.nome}`);
      console.log(`   ID: ${testCidadao.id}`);
      console.log(`   Status: ${testCidadao.status}`);

      // 3. Testar rota de análise
      console.log(`\n🧪 Testando PATCH /api/cidadaos/${testCidadao.id}/analyze`);
      
      try {
        const analyzeResponse = await axios.patch(
          `${API_BASE}/cidadaos/${testCidadao.id}/analyze`, 
          {}, 
          { headers: authHeaders }
        );
        console.log('✅ SUCESSO! Rota funcionando');
        console.log(`   Resposta: ${analyzeResponse.data.message}`);
        console.log(`   Status atualizado: ${analyzeResponse.data.data?.status}`);
      } catch (error) {
        console.log('❌ ERRO na rota de análise:');
        console.log(`   Status: ${error.response?.status}`);
        console.log(`   Erro: ${error.response?.data?.error || error.message}`);
        
        if (error.response?.status === 404) {
          console.log('\n💡 SOLUÇÃO: Reinicie o servidor backend');
          console.log('   1. Pare o servidor (Ctrl+C)');
          console.log('   2. Execute: npm start');
          console.log('   3. Execute este teste novamente');
        }
      }
    } else {
      console.log('❌ Nenhum cidadão encontrado para teste');
    }
  } catch (error) {
    console.log('❌ Erro ao buscar cidadãos');
  }
}

testSpecificRoute().catch(console.error);