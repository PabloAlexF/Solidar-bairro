const axios = require('axios');

async function testCidadao() {
  try {
    console.log('🧪 Testando CIDADÃO...');
    const data = {
      nome: 'João Silva',
      email: 'joao@teste.com',
      senha: '123456',
      telefone: '(31) 99999-9999',
      dataNascimento: '1990-01-01',
      ocupacao: 'Engenheiro',
      cpf: '11144477735',
      rg: '123456789',
      endereco: 'Rua A, 123 - Centro'
    };
    
    const response = await axios.post('http://localhost:3001/api/cidadaos', data);
    console.log('✅ Cidadão cadastrado:', response.data.success);
    
    if (response.data.success) {
      const login = await axios.post('http://localhost:3001/api/auth/login', {
        email: 'joao@teste.com',
        password: '123456'
      });
      console.log('✅ Login cidadão:', login.data.success);
    }
  } catch (error) {
    console.log('❌ Erro cidadão:', error.response?.data?.error || error.message);
  }
}

testCidadao();