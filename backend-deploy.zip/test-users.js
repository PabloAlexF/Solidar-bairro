const admin = require('firebase-admin');
const serviceAccount = require('./firebase-service-account.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://solidar-bairro-default-rtdb.firebaseio.com'
});

const db = admin.firestore();

async function testUsers() {
  console.log('🔍 Testando usuários específicos do chat...');

  // IDs dos participantes da conversa
  const userIds = ['sXj4BM7rrKkciVdeXTcu', 'Ss4yJlj0AXNmdZeE4goi'];
  const collections = ['cidadaos', 'comercios', 'ongs', 'familias', 'admins'];

  for (const userId of userIds) {
    console.log(`\n👤 Verificando usuário: ${userId}`);
    let found = false;

    for (const collectionName of collections) {
      try {
        const doc = await db.collection(collectionName).doc(userId).get();
        if (doc.exists) {
          const data = doc.data();
          console.log(`  ✅ ENCONTRADO em ${collectionName}:`, {
            id: doc.id,
            nome: data.nome || data.nomeCompleto || data.razaoSocial || data.nomeFantasia,
            tipo: data.tipo,
            email: data.email
          });
          found = true;
          break;
        }
      } catch (error) {
        console.log(`  ❌ Erro ao verificar ${collectionName}:`, error.message);
      }
    }

    if (!found) {
      console.log(`  🚨 Usuário ${userId} NÃO encontrado em nenhuma coleção!`);

      // Listar alguns documentos da coleção para debug
      console.log(`  🔍 Debug: Listando primeiros 5 documentos de cada coleção...`);
      for (const collectionName of collections) {
        try {
          const snapshot = await db.collection(collectionName).limit(5).get();
          console.log(`    📋 ${collectionName} (${snapshot.size} docs):`);
          snapshot.forEach(doc => {
            const data = doc.data();
            console.log(`      - ${doc.id}: ${data.nome || data.nomeCompleto || data.razaoSocial || data.nomeFantasia || 'sem nome'}`);
          });
        } catch (error) {
          console.log(`    ❌ Erro ao listar ${collectionName}:`, error.message);
        }
      }
    }
  }

  process.exit(0);
}

testUsers().catch(console.error);
