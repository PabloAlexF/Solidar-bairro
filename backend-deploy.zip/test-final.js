const axios = require('axios');

async function testFamiliaOnly() {
  console.log('🧪 Teste final - FAMÍLIA\n');
  
  try {
    // Cadastro
    const registerData = {
      nomeCompleto: 'Família Teste Final',
      email: 'final@teste.com',
      password: '123456',
      telefone: '(31) 99999-5555',
      endereco: 'Rua Final, 999',
      bairro: 'Centro',
      tipoMoradia: 'Casa Própria',
      rendaFamiliar: 'ate_500',
      criancas: 2,
      adultos: 2
    };
    
    console.log('📋 Cadastrando família...');
    const registerResponse = await axios.post('http://localhost:3001/api/familias', registerData);
    
    if (registerResponse.data.success) {
      console.log('✅ Cadastro realizado com sucesso!');
      console.log('👤 ID:', registerResponse.data.data.id);
      
      // Login
      console.log('\n🔐 Testando login...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const loginResponse = await axios.post('http://localhost:3001/api/auth/login', {
        email: 'final@teste.com',
        password: '123456'
      });
      
      if (loginResponse.data.success) {
        console.log('✅ Login realizado com sucesso!');
        console.log('👤 Usuário:', loginResponse.data.data.user.nomeCompleto);
        console.log('🎫 Token gerado:', !!loginResponse.data.data.token);
        console.log('\n🎉 SISTEMA DE AUTENTICAÇÃO FUNCIONANDO PERFEITAMENTE!');
      } else {
        console.log('❌ Login falhou:', loginResponse.data.error);
      }
      
    } else {
      console.log('❌ Cadastro falhou:', registerResponse.data.error);
    }
    
  } catch (error) {
    console.log('❌ Erro:', error.response?.data?.error || error.message);
  }
}

testFamiliaOnly();