const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

async function testarLoginDetalhado() {
  console.log('🔍 Teste detalhado de login\n');
  
  const timestamp = Date.now();
  
  // Dados únicos para teste
  const cidadaoData = {
    nome: 'Teste Login Detalhado',
    email: `teste.detalhado.${timestamp}@email.com`,
    telefone: '(31) 99999-9999',
    password: '123456',
    cep: '33400-000',
    rua: 'Rua Teste',
    numero: '123',
    bairro: 'Centro',
    cidade: 'Lagoa Santa',
    estado: 'MG'
  };

  try {
    // 1. CADASTRAR
    console.log('1️⃣ Cadastrando...');
    const cadastroResponse = await axios.post(`${BASE_URL}/cidadaos`, cidadaoData);
    console.log('Resposta cadastro:', JSON.stringify(cadastroResponse.data, null, 2));

    // 2. LOGIN
    console.log('\n2️⃣ Fazendo login...');
    const loginData = {
      email: cidadaoData.email,
      password: cidadaoData.password
    };

    const loginResponse = await axios.post(`${BASE_URL}/auth/login`, loginData);
    console.log('Resposta login completa:', JSON.stringify(loginResponse.data, null, 2));

    // 3. VERIFICAR SE TEM TOKEN
    if (loginResponse.data.data?.token) {
      console.log('\n3️⃣ Testando token...');
      
      try {
        const profileResponse = await axios.get(`${BASE_URL}/auth/verify`, {
          headers: {
            'Authorization': `Bearer ${loginResponse.data.data.token}`
          }
        });
        console.log('Resposta perfil:', JSON.stringify(profileResponse.data, null, 2));
      } catch (tokenError) {
        console.log('❌ Erro ao testar token:', tokenError.response?.data || tokenError.message);
      }
    }

    console.log('\n✅ Teste concluído com sucesso!');
    
  } catch (error) {
    console.log('\n❌ ERRO:');
    console.log('Status:', error.response?.status);
    console.log('Dados completos do erro:', JSON.stringify(error.response?.data, null, 2));
  }
}

testarLoginDetalhado();