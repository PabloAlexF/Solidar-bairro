const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

async function testAllRegistrationsAndLogins() {
  console.log('🧪 Testando todos os cadastros e logins...\n');
  
  const tests = [
    {
      name: 'CIDADÃO',
      registerUrl: `${BASE_URL}/cidadaos`,
      data: {
        nome: 'João Silva',
        email: 'joao@teste.com',
        password: '123456',
        telefone: '(31) 99999-9999',
        dataNascimento: '1990-01-01',
        ocupacao: 'Engenheiro',
        cpf: '11144477735',
        rg: '123456789',
        endereco: 'Rua A, 123 - Centro'
      }
    },
    {
      name: 'COMÉRCIO',
      registerUrl: `${BASE_URL}/comercios`,
      data: {
        nomeComercio: 'Padaria do João',
        email: 'padaria@teste.com',
        password: '123456',
        telefone: '(31) 99999-8888',
        cnpj: '11222333000181',
        endereco: 'Rua B, 456',
        categoria: 'Alimentação'
      }
    },
    {
      name: 'ONG',
      registerUrl: `${BASE_URL}/ongs`,
      data: {
        nome: 'ONG Solidária',
        email: 'ong@teste.com',
        password: '123456',
        telefone: '(31) 99999-7777',
        cnpj: '11222333000182',
        endereco: 'Rua C, 789',
        areasAtuacao: ['Educação'],
        responsavel: 'Maria Santos'
      }
    },
    {
      name: 'FAMÍLIA',
      registerUrl: `${BASE_URL}/familias`,
      data: {
        nomeCompleto: 'Família Silva',
        email: 'familia@teste.com',
        password: '123456',
        telefone: '(31) 99999-6666',
        endereco: 'Rua D, 101',
        bairro: 'Centro',
        tipoMoradia: 'Casa Própria',
        rendaFamiliar: 'ate_500',
        criancas: 1,
        adultos: 2
      }
    }
  ];

  for (const test of tests) {
    try {
      console.log(`📋 Testando ${test.name}...`);
      
      // 1. Cadastro
      const registerResponse = await axios.post(test.registerUrl, test.data);
      if (registerResponse.data.success) {
        console.log(`  ✅ Cadastro OK`);
      } else {
        console.log(`  ❌ Cadastro falhou:`, registerResponse.data.error);
        continue;
      }
      
      // 2. Login
      await new Promise(resolve => setTimeout(resolve, 1000)); // Aguardar 1s
      
      const loginResponse = await axios.post(`${BASE_URL}/auth/login`, {
        email: test.data.email,
        password: test.data.password
      });
      
      if (loginResponse.data.success) {
        console.log(`  ✅ Login OK`);
        console.log(`  👤 Usuário: ${loginResponse.data.data.user.nome || loginResponse.data.data.user.nomeCompleto || loginResponse.data.data.user.nomeComercio}`);
      } else {
        console.log(`  ❌ Login falhou:`, loginResponse.data.error);
      }
      
    } catch (error) {
      console.log(`  ❌ Erro:`, error.response?.data?.error || error.message);
    }
    
    console.log(''); // Linha em branco
  }
  
  console.log('🎉 Testes concluídos!');
}

testAllRegistrationsAndLogins();