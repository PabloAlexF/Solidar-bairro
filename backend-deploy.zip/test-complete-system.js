const axios = require('axios');

const API_BASE = 'http://localhost:3001/api';

// Test data for all user types
const testData = {
  familia: {
    nome: 'Família Silva',
    email: 'familia@test.com',
    password: '123456',
    telefone: '11999999999',
    endereco: 'Rua A, 123',
    bairro: 'Centro',
    cidade: 'São Paulo',
    estado: 'SP',
    cep: '01000-000',
    membros: [
      { nome: 'João Silva', idade: 35, parentesco: 'pai' },
      { nome: 'Maria Silva', idade: 32, parentesco: 'mãe' }
    ],
    rendaFamiliar: 2000,
    situacaoMoradia: 'própria'
  },
  cidadao: {
    nome: 'João Cidadão',
    email: 'cidadao@test.com',
    password: '123456',
    telefone: '11888888888',
    endereco: 'Rua B, 456',
    bairro: 'Vila Nova',
    cidade: 'São Paulo',
    estado: 'SP',
    cep: '02000-000',
    cpf: '12345678901',
    dataNascimento: '1990-01-01'
  },
  comercio: {
    nome: 'Mercado Central',
    email: 'comercio@test.com',
    password: '123456',
    telefone: '11777777777',
    endereco: 'Rua C, 789',
    bairro: 'Comercial',
    cidade: 'São Paulo',
    estado: 'SP',
    cep: '03000-000',
    cnpj: '12345678000195',
    tipoComercio: 'supermercado',
    horarioFuncionamento: '08:00-18:00'
  },
  ong: {
    nome: 'ONG Solidária',
    email: 'ong@test.com',
    password: '123456',
    telefone: '11666666666',
    endereco: 'Rua D, 101',
    bairro: 'Social',
    cidade: 'São Paulo',
    estado: 'SP',
    cep: '04000-000',
    cnpj: '98765432000123',
    areaAtuacao: 'assistência social',
    descricao: 'ONG que ajuda famílias carentes'
  }
};

async function testRegistration(userType, data) {
  try {
    console.log(`\n🔄 Testando cadastro de ${userType}...`);
    
    const response = await axios.post(`${API_BASE}/${userType}s`, data);
    
    if (response.status === 201) {
      console.log(`✅ Cadastro de ${userType} realizado com sucesso!`);
      console.log(`   ID: ${response.data.id || response.data.uid}`);
      return { success: true, id: response.data.id || response.data.uid };
    }
  } catch (error) {
    console.log(`❌ Erro no cadastro de ${userType}:`);
    console.log(`   Status: ${error.response?.status}`);
    console.log(`   Erro: ${error.response?.data?.error || error.message}`);
    return { success: false, error: error.response?.data?.error || error.message };
  }
}

async function testLogin(userType, email, password) {
  try {
    console.log(`\n🔄 Testando login de ${userType}...`);
    
    const response = await axios.post(`${API_BASE}/auth/login`, {
      email,
      password,
      userType
    });
    
    if (response.status === 200) {
      console.log(`✅ Login de ${userType} realizado com sucesso!`);
      console.log(`   Token: ${response.data.token ? 'Gerado' : 'Não gerado'}`);
      console.log(`   User: ${response.data.user?.nome || response.data.user?.name}`);
      return { success: true, token: response.data.token };
    }
  } catch (error) {
    console.log(`❌ Erro no login de ${userType}:`);
    console.log(`   Status: ${error.response?.status}`);
    console.log(`   Erro: ${error.response?.data?.error || error.message}`);
    return { success: false, error: error.response?.data?.error || error.message };
  }
}

async function runCompleteTest() {
  console.log('🚀 INICIANDO TESTE COMPLETO DO SISTEMA');
  console.log('=====================================');
  
  const results = {
    registrations: {},
    logins: {}
  };
  
  // Test registrations
  console.log('\n📝 TESTANDO CADASTROS');
  console.log('====================');
  
  for (const [userType, data] of Object.entries(testData)) {
    results.registrations[userType] = await testRegistration(userType, data);
    await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1s between requests
  }
  
  // Test logins
  console.log('\n🔐 TESTANDO LOGINS');
  console.log('==================');
  
  for (const [userType, data] of Object.entries(testData)) {
    results.logins[userType] = await testLogin(userType, data.email, data.password);
    await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1s between requests
  }
  
  // Summary
  console.log('\n📊 RESUMO DOS TESTES');
  console.log('====================');
  
  const regSuccess = Object.values(results.registrations).filter(r => r.success).length;
  const loginSuccess = Object.values(results.logins).filter(r => r.success).length;
  
  console.log(`\n📝 Cadastros: ${regSuccess}/4 sucessos`);
  console.log(`🔐 Logins: ${loginSuccess}/4 sucessos`);
  
  if (regSuccess === 4 && loginSuccess === 4) {
    console.log('\n🎉 TODOS OS TESTES PASSARAM! Sistema funcionando perfeitamente.');
  } else {
    console.log('\n⚠️  Alguns testes falharam. Verifique os erros acima.');
  }
  
  return results;
}

// Run the test
runCompleteTest().catch(console.error);