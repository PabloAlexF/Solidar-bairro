const axios = require('axios');

const BASE_URL = 'http://localhost:3001/api';

const dadosMobile = {
  cidadao: {
    nome: 'Roberto Carlos Santos',
    dataNascimento: '1990-08-25',
    ocupacao: 'Professor de Matemática',
    cpf: '777.888.999-00',
    rg: '45.678.901-2',
    telefone: '(31) 98888-9999',
    email: 'roberto.santos@email.com',
    password: 'senha123',
    confirmPassword: 'senha123',
    cep: '33400-000',
    endereco: 'Rua dos Girassóis',
    numero: '789',
    bairro: 'Vila Nova',
    cidade: 'Lagoa Santa',
    estado: 'MG',
    referencia: 'Próximo ao mercado',
    disponibilidade: ['Dias úteis', 'Período da manhã'],
    interesses: ['Aulas e Tutorias', 'Apoio Psicológico'],
    proposito: 'Quero ajudar crianças com dificuldades em matemática',
    termosAceitos: true
  },

  comercio: {
    nomeFantasia: 'Farmácia Saúde Total',
    segmento: 'saude',
    responsavel: 'Mariana Costa Silva',
    senha: 'senha123',
    confirmarSenha: 'senha123',
    cnpj: '11.222.333/0001-44',
    telefone: '(31) 3344-5566',
    email: 'farmacia.saudetotal@email.com',
    cep: '33400-000',
    endereco: 'Av. Central',
    numero: '1200',
    bairro: 'Centro',
    cidade: 'Lagoa Santa',
    estado: 'MG',
    horarioFuncionamento: 'Seg a Sex das 08h às 20h, Sáb das 08h às 14h',
    tiposContribuicao: ['Ponto de Coleta de Doações', 'Descontos para Famílias Cadastradas', 'Doação de Excedentes (Alimentos)'],
    observacoes: 'Temos interesse em apoiar a comunidade local',
    termosAceitos: true
  },

  ong: {
    nome: 'Associação Amigos do Bem',
    cnpj: '55.666.777/0001-88',
    email: 'contato@amigosdobem.org',
    telefone: '(31) 3355-6677',
    senha: 'senha123',
    confirmarSenha: 'senha123',
    cep: '33400-000',
    endereco: 'Rua da Fraternidade',
    numero: '456',
    bairro: 'Jardim das Flores',
    cidade: 'Lagoa Santa',
    estado: 'MG',
    areasAtuacao: ['Assistência Social', 'Saúde', 'Educação'],
    descricao: 'Assistência a comunidades carentes com foco em educação e saúde',
    responsavel: {
      nome: 'Fernando Alves',
      cpf: '333.444.555-66'
    },
    termosAceitos: true
  },

  familia: {
    nomeCompleto: 'Juliana Ferreira Lima',
    dataNascimento: '1985-11-30',
    estadoCivil: 'solteiro',
    profissao: 'Costureira',
    cpf: '666.777.888-99',
    rg: '34.567.890-2',
    nis: '11122233344',
    rendaFamiliar: 'ate-1-salario',
    telefone: '(31) 99666-5544',
    whatsapp: '(31) 99666-5544',
    email: 'juliana.lima@email.com',
    password: 'senha123',
    confirmPassword: 'senha123',
    horarioContato: 'noite',
    cep: '33400-000',
    endereco: 'Rua das Violetas',
    numero: '567',
    bairro: 'Bela Vista',
    cidade: 'Lagoa Santa',
    estado: 'MG',
    pontoReferencia: 'Perto da praça',
    tipoMoradia: 'alugada',
    criancas: 2,
    jovens: 0,
    adultos: 1,
    idosos: 0,
    necessidades: ['Alimentação Básica', 'Roupas e Calçados'],
    termosAceitos: true
  }
};

async function testarCidadaoMobile() {
  console.log('\n📱 === CIDADÃO MOBILE ===');
  try {
    const payload = {
      nome: dadosMobile.cidadao.nome,
      dataNascimento: dadosMobile.cidadao.dataNascimento,
      ocupacao: dadosMobile.cidadao.ocupacao,
      cpf: dadosMobile.cidadao.cpf,
      rg: dadosMobile.cidadao.rg,
      telefone: dadosMobile.cidadao.telefone,
      email: dadosMobile.cidadao.email,
      password: dadosMobile.cidadao.password,
      cep: dadosMobile.cidadao.cep,
      rua: dadosMobile.cidadao.endereco,
      numero: dadosMobile.cidadao.numero,
      bairro: dadosMobile.cidadao.bairro,
      cidade: dadosMobile.cidadao.cidade,
      estado: dadosMobile.cidadao.estado,
      referencia: dadosMobile.cidadao.referencia,
      disponibilidade: dadosMobile.cidadao.disponibilidade,
      interesses: dadosMobile.cidadao.interesses,
      proposito: dadosMobile.cidadao.proposito
    };
    const response = await axios.post(`${BASE_URL}/cidadaos`, payload);
    console.log('✅ Cadastrado:', response.data.data.nome);
    return response.data.data;
  } catch (error) {
    console.error('❌ Erro:', error.response?.data?.error || error.message);
    return null;
  }
}

async function testarComercioMobile() {
  console.log('\n📱 === COMÉRCIO MOBILE ===');
  try {
    const payload = {
      nomeComercio: dadosMobile.comercio.nomeFantasia,
      categoria: dadosMobile.comercio.segmento,
      responsavel: dadosMobile.comercio.responsavel,
      senha: dadosMobile.comercio.senha,
      cnpj: dadosMobile.comercio.cnpj,
      telefone: dadosMobile.comercio.telefone,
      email: dadosMobile.comercio.email,
      endereco: `${dadosMobile.comercio.endereco}, ${dadosMobile.comercio.numero}, ${dadosMobile.comercio.bairro}, ${dadosMobile.comercio.cidade} - ${dadosMobile.comercio.estado}`,
      horarioFuncionamento: dadosMobile.comercio.horarioFuncionamento,
      descricao: dadosMobile.comercio.observacoes
    };
    const response = await axios.post(`${BASE_URL}/comercios`, payload);
    console.log('✅ Cadastrado:', response.data.data.nomeComercio);
    return response.data.data;
  } catch (error) {
    console.error('❌ Erro:', error.response?.data?.error || error.message);
    return null;
  }
}

async function testarONGMobile() {
  console.log('\n📱 === ONG MOBILE ===');
  try {
    const response = await axios.post(`${BASE_URL}/ongs`, dadosMobile.ong);
    console.log('✅ Cadastrada:', response.data.data.nome);
    return response.data.data;
  } catch (error) {
    console.error('❌ Erro:', error.response?.data?.error || error.message);
    return null;
  }
}

async function testarFamiliaMobile() {
  console.log('\n📱 === FAMÍLIA MOBILE ===');
  try {
    const response = await axios.post(`${BASE_URL}/familias`, dadosMobile.familia);
    console.log('✅ Cadastrada:', response.data.data.nomeCompleto);
    console.log('   Membros:', dadosMobile.familia.criancas + dadosMobile.familia.adultos);
    return response.data.data;
  } catch (error) {
    console.error('❌ Erro:', error.response?.data?.error || error.message);
    return null;
  }
}

async function executarTesteMobile() {
  console.log('📱 TESTE CADASTROS MOBILE');
  console.log('=========================\n');
  
  await testarCidadaoMobile();
  await testarComercioMobile();
  await testarONGMobile();
  await testarFamiliaMobile();
  
  console.log('\n=========================');
  console.log('✅ TESTE MOBILE CONCLUÍDO!');
  console.log('=========================\n');
}

if (require.main === module) {
  executarTesteMobile().catch(console.error);
}

module.exports = { executarTesteMobile, dadosMobile };
