const BotController = require('./src/controllers/botController');

console.log('🤖 Testando Bot Inteligente SolidarBrasil\n');

// Casos de teste
const testCases = [
  {
    name: '✅ Pedido Válido - Alimentos Crítico',
    data: {
      category: 'Alimentos',
      description: 'Preciso urgentemente de ajuda com comida para minha família. Somos 4 pessoas, tenho 2 filhos pequenos de 3 e 5 anos. Estou desempregado há 3 meses e a situação está crítica.',
      urgency: 'critico'
    }
  },
  {
    name: '❌ Spam Detectado - Texto Repetitivo',
    data: {
      category: 'Alimentos',
      description: 'dawdawdaw dawdawdaw preciso ajuda dawdawdaw dawdawdaw',
      urgency: 'urgente'
    }
  },
  {
    name: '❌ Categoria Incorreta - Medicamento como Alimento',
    data: {
      category: 'Alimentos',
      description: 'Preciso de remédio para pressão alta, estou sem dinheiro para comprar na farmácia',
      urgency: 'urgente'
    }
  },
  {
    name: '❌ Urgência Incompatível - Crítico sem justificativa',
    data: {
      category: 'Roupas',
      description: 'Gostaria de algumas roupas quando possível, sem pressa',
      urgency: 'critico'
    }
  },
  {
    name: '✅ Pedido Válido - Medicamentos Urgente',
    data: {
      category: 'Medicamentos',
      description: 'Minha mãe precisa urgentemente de remédio para diabetes, acabou o estoque e ela não pode ficar sem',
      urgency: 'urgente'
    }
  },
  {
    name: '✅ Pedido Válido - Roupas Tranquilo',
    data: {
      category: 'Roupas',
      description: 'Preciso de roupas para meus filhos, sem pressa, quando possível',
      urgency: 'tranquilo'
    }
  }
];

// Executar testes
let passed = 0;
let failed = 0;

console.log('📋 Executando testes...\n');

testCases.forEach((testCase, index) => {
  console.log(`${index + 1}. ${testCase.name}`);
  console.log(`   Categoria: ${testCase.data.category}`);
  console.log(`   Urgência: ${testCase.data.urgency}`);
  console.log(`   Descrição: "${testCase.data.description.substring(0, 60)}..."`);
  
  try {
    const result = BotController.validateRequestIntelligent(testCase.data);
    
    console.log(`   📊 Resultado: ${result.isValid ? '✅ APROVADO' : '❌ REJEITADO'}`);
    console.log(`   🎯 Confiança: ${result.confidence}%`);
    console.log(`   📝 Análise: ${result.analysis}`);
    
    if (result.suggestions.length > 0) {
      console.log(`   💡 Sugestões: ${result.suggestions.join('; ')}`);
    }
    
    // Verificar se o resultado esperado está correto
    const shouldPass = testCase.name.startsWith('✅');
    if ((result.isValid && shouldPass) || (!result.isValid && !shouldPass)) {
      passed++;
      console.log(`   ✅ Teste passou conforme esperado`);
    } else {
      failed++;
      console.log(`   ❌ Teste falhou - resultado inesperado`);
    }
    
  } catch (error) {
    failed++;
    console.log(`   💥 Erro: ${error.message}`);
  }
  
  console.log('');
});

// Resumo
console.log('📈 RESUMO DOS TESTES');
console.log('='.repeat(50));
console.log(`Total de testes: ${testCases.length}`);
console.log(`✅ Passou: ${passed}`);
console.log(`❌ Falhou: ${failed}`);
console.log(`📊 Taxa de sucesso: ${Math.round((passed / testCases.length) * 100)}%`);

if (failed === 0) {
  console.log('\n🎉 Todos os testes passaram! Bot está funcionando perfeitamente.');
} else {
  console.log(`\n⚠️  ${failed} teste(s) falharam. Verifique a implementação.`);
}