const axios = require('axios');

const API_BASE = 'http://localhost:3001/api';

async function testConcluirAnalise() {
  console.log('🔍 TESTE - FUNCIONALIDADE "CONCLUIR ANÁLISE"\n');

  // 1. Verificar backend
  try {
    const response = await axios.get('http://localhost:3001/health');
    console.log('✅ Backend funcionando:', response.data.status);
  } catch (error) {
    console.log('❌ Backend não está funcionando!');
    return;
  }

  // 2. Buscar item pendente para testar
  console.log('\n📋 BUSCANDO ITENS PENDENTES...\n');

  let itemPendente = null;
  let tipoItem = null;
  let endpoint = null;

  // Verificar famílias pendentes
  try {
    const response = await axios.get(`${API_BASE}/familias`);
    const familias = response.data.data || response.data || [];
    const pendentes = familias.filter(f => f.status === 'pending');
    
    if (pendentes.length > 0) {
      itemPendente = pendentes[0];
      tipoItem = 'família';
      endpoint = '/familias';
      console.log(`✅ Encontrada família pendente: ${itemPendente.nomeCompleto}`);
      console.log(`   ID: ${itemPendente.id}`);
      console.log(`   Status atual: ${itemPendente.status || 'pending'}`);
    }
  } catch (error) {
    console.log('❌ Erro ao buscar famílias');
  }

  // Se não encontrou família, verificar cidadãos
  if (!itemPendente) {
    try {
      const response = await axios.get(`${API_BASE}/cidadaos`);
      const cidadaos = response.data.data || response.data || [];
      const pendentes = cidadaos.filter(c => c.status === 'pending');
      
      if (pendentes.length > 0) {
        itemPendente = pendentes[0];
        tipoItem = 'cidadão';
        endpoint = '/cidadaos';
        console.log(`✅ Encontrado cidadão pendente: ${itemPendente.nome || itemPendente.nomeCompleto}`);
        console.log(`   ID: ${itemPendente.uid || itemPendente.id}`);
        console.log(`   Status atual: ${itemPendente.status || 'pending'}`);
      }
    } catch (error) {
      console.log('❌ Erro ao buscar cidadãos');
    }
  }

  // Se não encontrou nenhum, verificar ONGs
  if (!itemPendente) {
    try {
      const response = await axios.get(`${API_BASE}/ongs`);
      const ongs = response.data.data || response.data || [];
      const pendentes = ongs.filter(o => o.status === 'pending');
      
      if (pendentes.length > 0) {
        itemPendente = pendentes[0];
        tipoItem = 'ONG';
        endpoint = '/ongs';
        console.log(`✅ Encontrada ONG pendente: ${itemPendente.nome_fantasia}`);
        console.log(`   ID: ${itemPendente.id}`);
        console.log(`   Status atual: ${itemPendente.status || 'pending'}`);
      }
    } catch (error) {
      console.log('❌ Erro ao buscar ONGs');
    }
  }

  if (!itemPendente) {
    console.log('⚠️ Nenhum item pendente encontrado para testar');
    console.log('💡 Execute: node criar-pendentes.js para criar itens de teste');
    return;
  }

  // 3. Testar a API de atualização de status
  console.log(`\n🔧 TESTANDO API DE ATUALIZAÇÃO DE STATUS...\n`);

  const itemId = itemPendente.uid || itemPendente.id;
  
  try {
    console.log(`📤 Enviando PATCH para ${endpoint}/${itemId}`);
    console.log(`   Payload: { status: "analyzed" }`);
    
    const response = await axios.patch(`${API_BASE}${endpoint}/${itemId}`, {
      status: 'analyzed'
    });
    
    console.log('✅ API de atualização funcionou!');
    console.log(`   Status da resposta: ${response.status}`);
    console.log(`   Resposta:`, response.data);
    
  } catch (error) {
    console.log('❌ Erro na API de atualização:');
    console.log(`   Status: ${error.response?.status}`);
    console.log(`   Erro: ${error.response?.data?.error || error.message}`);
    
    // Se deu erro, pode ser que a API espere um formato diferente
    console.log('\n🔄 Tentando formato alternativo...');
    
    try {
      const response2 = await axios.put(`${API_BASE}${endpoint}/${itemId}`, {
        status: 'analyzed'
      });
      console.log('✅ API de atualização funcionou com PUT!');
      console.log(`   Status da resposta: ${response2.status}`);
    } catch (error2) {
      console.log('❌ Erro também com PUT:', error2.response?.data?.error || error2.message);
    }
  }

  // 4. Verificar se o status foi atualizado
  console.log(`\n🔍 VERIFICANDO SE O STATUS FOI ATUALIZADO...\n`);

  try {
    const response = await axios.get(`${API_BASE}${endpoint}/${itemId}`);
    const itemAtualizado = response.data.data || response.data;
    
    console.log(`📊 Status do item após atualização:`);
    console.log(`   Nome: ${itemAtualizado.nome_fantasia || itemAtualizado.nomeCompleto || itemAtualizado.nome}`);
    console.log(`   Status: ${itemAtualizado.status}`);
    
    if (itemAtualizado.status === 'analyzed') {
      console.log('✅ STATUS ATUALIZADO COM SUCESSO!');
    } else {
      console.log('❌ Status não foi atualizado');
    }
    
  } catch (error) {
    console.log('❌ Erro ao verificar status atualizado:', error.message);
  }

  // 5. Verificar dados gerais após atualização
  console.log(`\n📊 VERIFICANDO DADOS GERAIS APÓS ATUALIZAÇÃO...\n`);

  const apis = [
    { name: 'ONGs', url: '/ongs' },
    { name: 'Famílias', url: '/familias' },
    { name: 'Cidadãos', url: '/cidadaos' }
  ];

  let totalPendentes = 0;
  let totalAnalisados = 0;

  for (const api of apis) {
    try {
      const response = await axios.get(`${API_BASE}${api.url}`);
      const data = response.data.data || response.data || [];
      
      const pendentes = data.filter(item => item.status === 'pending' || !item.status).length;
      const analisados = data.filter(item => item.status === 'analyzed').length;
      
      totalPendentes += pendentes;
      totalAnalisados += analisados;
      
      console.log(`${api.name}: ${data.length} total, ${pendentes} pendentes, ${analisados} analisados`);
      
    } catch (error) {
      console.log(`❌ ${api.name}: Erro na API`);
    }
  }

  console.log(`\n📈 RESUMO APÓS TESTE:`);
  console.log(`   Total pendentes: ${totalPendentes}`);
  console.log(`   Total analisados: ${totalAnalisados}`);

  // 6. Instruções para teste manual
  console.log(`\n🧪 COMO TESTAR MANUALMENTE NO DASHBOARD MOBILE:\n`);
  
  console.log('1. Acesse: http://localhost:3000/admin');
  console.log('2. Login: joao@teste.com / 123456');
  console.log('3. Ative modo mobile (F12 → Device Toolbar)');
  console.log('4. Vá para aba "Início"');
  
  if (totalPendentes > 0) {
    console.log('5. Na seção "Aguardando Ação", clique em "Analisar"');
    console.log('6. No modal que abrir:');
    console.log('   - Marque os 2 checkboxes do checklist');
    console.log('   - Clique em "Concluir Análise"');
    console.log('7. Deve aparecer modal de sucesso');
    console.log('8. O item deve sair da lista "Aguardando Ação"');
    console.log('9. A meta de aprovação deve aumentar');
  } else {
    console.log('5. ✅ Não há itens pendentes (todos foram analisados)');
    console.log('6. Deve aparecer "Excelente! Sem pendências."');
  }

  console.log(`\n🎯 FUNCIONALIDADE "CONCLUIR ANÁLISE":`);
  
  if (totalAnalisados > 0) {
    console.log('✅ FUNCIONANDO - Itens foram marcados como analisados');
  } else {
    console.log('⚠️ VERIFICAR - Nenhum item foi marcado como analisado');
  }

  console.log('\n🎉 TESTE DE "CONCLUIR ANÁLISE" CONCLUÍDO!');
}

testConcluirAnalise().catch(console.error);