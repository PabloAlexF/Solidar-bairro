const ongService = require('../services/ongService');
const authService = require('../services/authService');

class ONGController {
  async createONG(req, res) {
    try {
      const result = await ongService.createONG(req.body);

      // Enviar email de boas-vindas
      try {
        await emailService.sendWelcomeEmail(req.body.email, req.body.nome);
        console.log('Email de boas-vindas enviado para:', req.body.email);
      } catch (emailError) {
        console.error('Erro ao enviar email de boas-vindas:', emailError);
        // Não falhar o cadastro por causa do email
      }

      res.status(201).json({ success: true, data: result });
    } catch (error) {
      res.status(400).json({ success: false, error: error.message });
    }
  }

  async getONGs(req, res) {
    try {
      const ongs = await ongService.getONGs();
      res.json({ success: true, data: ongs });
    } catch (error) {
      res.status(500).json({ success: false, error: error.message });
    }
  }

  async getONGById(req, res) {
    try {
      const ong = await ongService.getONGById(req.params.uid);
      res.json({ success: true, data: ong });
    } catch (error) {
      res.status(404).json({ success: false, error: error.message });
    }
  }

  async updateONG(req, res) {
    try {
      const ong = await ongService.updateONG(req.params.uid, req.body);
      res.json({ success: true, data: ong });
    } catch (error) {
      res.status(400).json({ success: false, error: error.message });
    }
  }

  async markAsAnalyzed(req, res) {
    try {
      const updateData = {
        status: 'analyzed',
        analyzedAt: new Date(),
        analyzedBy: 'admin'
      };
      const ong = await ongService.updateONG(req.params.uid, updateData);
      res.json({ success: true, data: ong, message: 'ONG marcada como analisada' });
    } catch (error) {
      res.status(400).json({ success: false, error: error.message });
    }
  }
}

module.exports = new ONGController();